import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as cors from "cors";

admin.initializeApp();
const db = admin.firestore();
const corsHandler = cors({ origin: true });

export const api = functions.https.onRequest((req, res) => {
  corsHandler(req, res, async () => {
    // verify firebase ID token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "No token" });
      return;
    }

    const idToken = authHeader.split(" ")[1];

    let uid: string;
    try {
      const decoded = await admin.auth().verifyIdToken(idToken);
      uid = decoded.uid;
    } catch (err) {
      console.error("Token verify failed", err);
      res.status(401).json({ error: "Invalid token" });
      return;
    }

    const path = req.path;

    // GET /questions
    if (req.method === "GET" && path === "/questions") {
      const docRef = db
        .collection("users")
        .doc(uid)
        .collection("questionBank")
        .doc("main");
      const snap = await docRef.get();
      const data = snap.exists ? snap.data() : { questions: [] };
      res.json(data);
      return;
    }

    // POST /questions
    if (req.method === "POST" && path === "/questions") {
      const questions = req.body?.questions ?? [];
      const docRef = db
        .collection("users")
        .doc(uid)
        .collection("questionBank")
        .doc("main");
      await docRef.set({ questions }, { merge: true });
      res.json({ ok: true });
      return;
    }

    res.status(404).json({ error: "Not found" });
  });
});
