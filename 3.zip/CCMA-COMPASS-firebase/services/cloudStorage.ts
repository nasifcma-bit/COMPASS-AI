import { auth, db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { Question, AnalyticsData } from '../types';

function requireUid(): string {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('User not logged in');
  }
  return user.uid;
}

export async function loadUserQuestionsFromCloud(): Promise<Question[]> {
  const uid = requireUid();
  const ref = doc(db, 'users', uid, 'questionBank', 'main');
  const snap = await getDoc(ref);
  return snap.exists() ? ((snap.data() as any).questions as Question[]) : [];
}

export async function saveUserQuestionsToCloud(questions: Question[]): Promise<void> {
  const uid = requireUid();
  const ref = doc(db, 'users', uid, 'questionBank', 'main');
  await setDoc(ref, { questions });
}

export async function loadAnalyticsFromCloud(): Promise<AnalyticsData | null> {
  const uid = requireUid();
  const ref = doc(db, 'users', uid, 'analytics', 'main');
  const snap = await getDoc(ref);
  return snap.exists() ? (snap.data() as AnalyticsData) : null;
}

export async function saveAnalyticsToCloud(data: AnalyticsData): Promise<void> {
  const uid = requireUid();
  const ref = doc(db, 'users', uid, 'analytics', 'main');
  await setDoc(ref, data, { merge: true });
}
