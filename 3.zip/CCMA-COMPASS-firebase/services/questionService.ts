import { apiGet } from './apiClient';
import { Question } from '../types';

export const transformRawQuestions = (rawData: any, source: 'import' | 'user' | 'system'): Question[] => {
    const questions: Question[] = [];

    const processItem = (item: any, defaultSection?: string): Question | null => {
        // Format 1: Standard format
        if (item.id && item.question && Array.isArray(item.choices) && item.answer) {
             return {
                id: item.id,
                part: item.part || 'Part 2',
                section: item.section || defaultSection || 'General',
                topic: item.topic || 'General',
                question: item.question,
                choices: Array.isArray(item.choices) ? item.choices.map(String) : [],
                answer: {
                    index: item.answer.index,
                    explanation: item.answer.explanation || 'No explanation provided.'
                },
                difficulty: item.difficulty || 'medium',
                type: item.type || 'theory',
                source,
             };
        } 
        // Format 2: More complex, nested format
        else if (item.question_id && item.stem && Array.isArray(item.choices)) {
            const correctIndex = Array.isArray(item.choices) ? item.choices.findIndex((c: any) => c.label === item.correct) : -1;
            if (correctIndex !== -1) {
                return {
                    id: item.question_id,
                    part: item.part || 'Part 2',
                    section: item.section || defaultSection || 'General',
                    topic: item.topic || 'General',
                    question: item.stem,
                    choices: item.choices.map((c: any) => c.text ? String(c.text).trim() : String(c)),
                    answer: {
                        index: correctIndex,
                        explanation: item.explanation || 'No explanation provided.'
                    },
                    difficulty: item.difficulty || 'medium',
                    type: item.type || 'theory',
                    source,
                };
            }
        }
        return null;
    }

    // Handle top-level 'questions' array format
    if (Array.isArray(rawData.questions)) {
        for (const item of rawData.questions) {
            const question = processItem(item);
            if (question) questions.push(question);
        }
    }
    // Handle 'sections' object format
    else if (rawData.sections) { 
        for (const sectionKey in rawData.sections) {
            const sectionArray = rawData.sections[sectionKey];
            if (Array.isArray(sectionArray)) {
                for (const item of sectionArray) {
                    const sectionName = `Sec ${sectionKey.replace('Sec ', '').split(' ')[0]}`;
                    const question = processItem(item, sectionName);
                    if(question) questions.push(question);
                }
            }
        }
    }
     // Handle root array format
    else if (Array.isArray(rawData)) {
        for (const item of rawData) {
            const question = processItem(item);
            if (question) questions.push(question);
        }
    }

    return questions;
}


export const loadAndTransformUserQuestions = async (): Promise<Question[]> => {
    // 1) try external backend (Firebase Function)
    try {
        const remote = await apiGet<{ questions?: any[] } | any[]>('/questions');
        const rawQuestions = Array.isArray(remote) ? remote : (remote.questions || []);
        const transformed = transformRawQuestions(rawQuestions, 'import');
        if (transformed.length > 0) {
            return transformed;
        }
    } catch (e) {
        console.warn('Backend /questions failed, falling back to /data/user_provided_questions.json', e);
    }
    // 2) fall back to static file
    try {
        const response = await fetch('/data/user_provided_questions.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const rawData = await response.json();
        return transformRawQuestions(rawData, 'import');
    } catch (error) {
        console.error("Failed to load and transform user-provided questions:", error);
        return []; 
    }
};
