import { GoogleGenAI, Type } from "@google/genai";
import { Question, LOS } from "../types";

// Initialize the Google AI client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const explainConcept = async (concept: string, context: string, types: string[]): Promise<string> => {
    try {
        const sectionPrompts: { [key: string]: string } = {
            "ELI5": "### ELI5 (Explain Like I'm 5)\nProvide a very simple, real-world analogy.",
            "Formal Definition": "### The Formal Definition\nGive the concise, textbook definition.",
            "How It Works": "### How It Works / Key Components\nBreak it down into key parts or steps using a bulleted or numbered list.",
            "Practical Example": "### Practical Example\nProvide a concrete, scenario-based example with numbers if applicable.",
            "CMA Exam Pro-Tip": "### 💡 CMA Exam Pro-Tip\nOffer a key insight for the exam, like a common pitfall, a formula to remember, or how it's typically tested. Use the lightbulb emoji."
        };

        const requestedSections = types.map(type => sectionPrompts[type] as string).filter(Boolean).join('\n\n');
        
        if (!requestedSections) {
            // Fallback in case an empty array is passed, though the UI should prevent this.
            return "Please select at least one explanation type to generate.";
        }
        
        const prompt = `Act as an expert CMA exam tutor. Explain the concept: "${concept}".
        ${context ? `Specifically, address this question: "${context}".` : ''}

        Structure your explanation to ONLY include the following sections using markdown, in the order they are provided below:

        ${requestedSections}`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error explaining concept:", error);
        throw new Error("Failed to get explanation from AI. Please check your API key and try again.");
    }
};

const questionSchema = {
    type: Type.OBJECT,
    properties: {
        id: { type: Type.STRING, description: 'A unique ID for the question (e.g., UUID-like string).' },
        part: { type: Type.STRING, description: 'The part of the exam this question belongs to (e.g., "Part 1").' },
        section: { type: Type.STRING, description: 'The primary section or module this question covers.' },
        topic: { type: Type.STRING, description: 'The specific topic within the section.' },
        question: { type: Type.STRING, description: 'The question text.' },
        choices: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'An array of 4-5 multiple-choice options.' },
        answer: {
            type: Type.OBJECT,
            properties: {
                index: { type: Type.INTEGER, description: 'The 0-based index of the correct answer in the choices array.' },
                explanation: { type: Type.STRING, description: 'A brief explanation of why the answer is correct.' }
            },
            required: ['index', 'explanation']
        },
        difficulty: { type: Type.STRING, description: 'The difficulty level ("easy", "medium", or "hard").' },
        type: { type: Type.STRING, description: 'The question type ("theory" or "problem").' }
    },
    required: ['id', 'part', 'section', 'topic', 'question', 'choices', 'answer', 'difficulty', 'type']
};


export const generateQuestionsForConcept = async (concept: string, count: number): Promise<Question[]> => {
    try {
        const prompt = `Generate ${count} multiple-choice practice questions about the accounting concept: "${concept}".
        The questions should be suitable for a student preparing for a certification exam.
        For each question, provide the question text, 4-5 choices, the index of the correct answer, a brief explanation, the exam part, section, topic, difficulty, and type. Ensure each question has a unique id.
        Format the output as a JSON array.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.ARRAY,
                    items: questionSchema,
                }
            }
        });

        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating questions:", error);
        throw new Error("Failed to generate questions. The AI may be experiencing issues.");
    }
};


export const generateQuestions = async (part: string, section: string, topic: string, count: number, difficulty: string, type: string): Promise<Question[]> => {
    try {
        const topicInstruction = topic === 'All Topics' 
            ? `from any topic within the "${section}" section.`
            : `specifically about the topic "${topic}" within the "${section}" section.`;

        const prompt = `Generate ${count} multiple-choice practice questions for the CMA exam.
        The questions should be for ${part}, focusing on the "${section}" section.
        Specifically, generate questions ${topicInstruction}
        The questions should have a difficulty of "${difficulty}" and be of type "${type}".
        For each question, provide the question text, 4-5 choices, the index of the correct answer, a brief explanation, and a unique id. The section and topic for each generated question must be accurate.
        Format the output as a JSON array.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.ARRAY,
                    items: questionSchema,
                }
            }
        });

        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating questions for section/topic:", error);
        throw new Error("Failed to generate questions. The AI may be experiencing issues.");
    }
};

export const generateStudyPlan = async (examDate: string, weakAreas: string[]): Promise<string> => {
    try {
        const prompt = `Act as a professional CMA exam tutor.
        My exam is on ${examDate}.
        My self-identified weak areas are: ${weakAreas.join(', ')}.
        
        Create a structured, week-by-week study plan for me from today until the exam date.
        For each week, provide a high-level focus theme, list specific topics to cover (prioritizing my weak areas), and suggest a realistic number of practice questions to complete.
        The plan should be encouraging and actionable. Use markdown for formatting (e.g., headers for weeks, bullet points for topics).
        Start with a brief motivational opening and end with a concluding tip.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error generating study plan:", error);
        throw new Error("Failed to generate a study plan. Please try again.");
    }
};