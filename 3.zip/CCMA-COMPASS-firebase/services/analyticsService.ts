import { db, auth } from './firebase';
import { doc, getDoc, setDoc, collection, writeBatch } from 'firebase/firestore';
import { AnalyticsData, Question, SessionSummary, Badge, AnswerRecord } from "../types";

const ALL_BADGES: Omit<Badge, 'unlocked'>[] = [
    { id: 'session_1', name: 'First Step', description: 'Complete your first practice session.', icon: '🎓' },
    { id: 'session_10', name: 'Dedicated Learner', description: 'Complete 10 practice sessions.', icon: '📚' },
    { id: 'q_50', name: 'Question Quester', description: 'Answer 50 questions.', icon: '🎯' },
    { id: 'q_200', name: 'Question Conqueror', description: 'Answer 200 questions.', icon: '🏆' },
    { id: 'streak_3', name: 'On a Roll', description: 'Maintain a 3-day practice streak.', icon: '🔥' },
    { id: 'streak_7', name: 'Weekly Warrior', description: 'Maintain a 7-day practice streak.', icon: '🗓️' },
    { id: 'accuracy_90', name: 'Top Performer', description: 'Achieve 90% accuracy in a session.', icon: '⭐' },
    { id: 'builder_1', name: 'Creator', description: 'Add your first custom question.', icon: '✍️' },
];

export const getDefaultAnalytics = (): AnalyticsData => ({
  bySection: {},
  sessionHistory: [],
  flaggedQuestions: [],
  gamification: {
      dailyStreak: 0,
      lastPracticeDate: null,
      badges: ALL_BADGES.map(b => ({...b, unlocked: false }))
  },
  answerHistory: [],
});

const getUserId = (): string => {
    const user = auth.currentUser;
    if (!user) {
        throw new Error("No user is currently logged in. Cannot perform data operation.");
    }
    return user.uid;
};

export const loadAnalytics = async (): Promise<AnalyticsData> => {
    try {
        const userId = getUserId();
        const docRef = doc(db, 'users', userId, 'analytics', 'main');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            const parsed = docSnap.data() as AnalyticsData;
            const defaults = getDefaultAnalytics();
             // Gracefully migrate old data structure if needed
            if((parsed as any).answeredQuestions || (parsed as any).confidenceRatings) {
                delete (parsed as any).answeredQuestions;
                delete (parsed as any).confidenceRatings;
            }

            return {
                ...defaults,
                ...parsed,
                gamification: {
                    ...defaults.gamification,
                    ...(parsed.gamification || {}),
                    badges: ALL_BADGES.map(b => {
                        const savedBadge = parsed.gamification?.badges?.find((sb: Badge) => sb.id === b.id);
                        return { ...b, unlocked: savedBadge?.unlocked || false };
                    })
                },
                answerHistory: parsed.answerHistory || [],
            };
        }
    } catch (error) {
        console.error("Failed to load analytics data:", error);
    }
    return getDefaultAnalytics();
};

const saveAnalytics = async (data: AnalyticsData) => {
    try {
        const userId = getUserId();
        const docRef = doc(db, 'users', userId, 'analytics', 'main');
        await setDoc(docRef, data);
    } catch (error) {
        console.error("Failed to save analytics data:", error);
    }
};

export const recordAnswer = async (question: Question, isCorrect: boolean, timeTaken: number) => {
  const analytics = await loadAnalytics();
  const { id, section, topic, part } = question;

  if (!analytics.bySection[section]) {
    analytics.bySection[section] = {};
  }
  if (!analytics.bySection[section][topic]) {
    analytics.bySection[section][topic] = { correct: 0, total: 0, totalTime: 0 };
  }

  const topicStats = analytics.bySection[section][topic];
  topicStats.total += 1;
  topicStats.totalTime += timeTaken;
  if (isCorrect) {
    topicStats.correct += 1;
  }

  const newRecord: AnswerRecord = {
      questionId: id,
      isCorrect,
      part,
      section,
      topic,
      date: new Date().toISOString()
  };
  analytics.answerHistory.push(newRecord);

  await saveAnalytics(analytics);
};

export const recordConfidence = async (questionId: string, confidence: 'low' | 'medium' | 'high') => {
    const analytics = await loadAnalytics();
    let lastEntryIndex = -1;
    for (let i = analytics.answerHistory.length - 1; i >= 0; i--) {
        if (analytics.answerHistory[i].questionId === questionId) {
            lastEntryIndex = i;
            break;
        }
    }

    if (lastEntryIndex > -1) {
        analytics.answerHistory[lastEntryIndex].confidence = confidence;
        await saveAnalytics(analytics);
    }
};


export const toggleFlaggedQuestion = async (questionId: string) => {
  const analytics = await loadAnalytics();
  const index = analytics.flaggedQuestions.indexOf(questionId);

  if (index > -1) {
    analytics.flaggedQuestions.splice(index, 1);
  } else {
    analytics.flaggedQuestions.push(questionId);
  }
  await saveAnalytics(analytics);
};

const updateGamification = (analytics: AnalyticsData, sessionSummary: SessionSummary) => {
    const today = new Date();
    today.setHours(0,0,0,0);
    const lastPractice = analytics.gamification.lastPracticeDate ? new Date(analytics.gamification.lastPracticeDate) : null;
    if(lastPractice) lastPractice.setHours(0,0,0,0);
    
    if (!lastPractice || today.getTime() !== lastPractice.getTime()) {
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);
        
        if (lastPractice && lastPractice.getTime() === yesterday.getTime()) {
            analytics.gamification.dailyStreak += 1;
        } else {
            analytics.gamification.dailyStreak = 1;
        }
        analytics.gamification.lastPracticeDate = today.toISOString();
    }

    const totalQuestions = analytics.answerHistory.length;

    const checkAndUnlock = (badgeId: string, condition: boolean) => {
        const badge = analytics.gamification.badges.find(b => b.id === badgeId);
        if(badge && !badge.unlocked && condition) {
            badge.unlocked = true;
        }
    };

    checkAndUnlock('session_1', analytics.sessionHistory.length === 1);
    checkAndUnlock('session_10', analytics.sessionHistory.length >= 10);
    checkAndUnlock('q_50', totalQuestions >= 50);
    checkAndUnlock('q_200', totalQuestions >= 200);
    checkAndUnlock('streak_3', analytics.gamification.dailyStreak >= 3);
    checkAndUnlock('streak_7', analytics.gamification.dailyStreak >= 7);
    checkAndUnlock('accuracy_90', sessionSummary.accuracy >= 90);
    
    return analytics;
};

export const recordSessionSummary = async (summary: Omit<SessionSummary, 'date'>) => {
  let analytics = await loadAnalytics();
  const newSummary: SessionSummary = {
    ...summary,
    date: new Date().toISOString(),
  };
  analytics.sessionHistory.push(newSummary);
  
  if(analytics.sessionHistory.length > 20) {
      analytics.sessionHistory.shift();
  }

  analytics = updateGamification(analytics, newSummary);

  await saveAnalytics(analytics);
};


export const unlockBuilderBadge = async () => {
    const analytics = await loadAnalytics();
    const badge = analytics.gamification.badges.find(b => b.id === 'builder_1');
    if (badge && !badge.unlocked) {
        badge.unlocked = true;
        await saveAnalytics(analytics);
    }
};

export const loadUserQuestionBank = async (): Promise<Question[]> => {
    try {
        const userId = getUserId();
        const docRef = doc(db, 'users', userId, 'questionBank', 'main');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists() && docSnap.data().questions) {
            return docSnap.data().questions as Question[];
        }
    } catch (error) {
        console.error("Failed to load user question bank:", error);
    }
    return [];
};

export const saveUserQuestionBank = async (questions: Question[]) => {
    try {
        const userId = getUserId();
        const docRef = doc(db, 'users', userId, 'questionBank', 'main');
        await setDoc(docRef, { questions });
    } catch (error) {
        console.error("Failed to save user question bank:", error);
    }
};

export const calculatePerformanceMetrics = (answerHistory: AnswerRecord[]) => {
    const metrics = {
        totalQuestions: answerHistory.length,
        totalCorrect: 0,
        confidenceMatrix: {
            mastery: { count: 0, questions: [] as string[] }, // high conf, correct
            uncertain: { count: 0, questions: [] as string[] }, // low/med conf, correct
            learning: { count: 0, questions: [] as string[] }, // low/med conf, incorrect
            danger: { count: 0, questions: [] as string[] }, // high conf, incorrect
        },
        topicStats: new Map<string, { correct: number; total: number; incorrectHighConfidence: number, part: 'Part 1' | 'Part 2', section: string }>(),
    };

    for (const record of answerHistory) {
        if (record.isCorrect) metrics.totalCorrect++;

        if (record.isCorrect) {
            if (record.confidence === 'high') {
                metrics.confidenceMatrix.mastery.count++;
                metrics.confidenceMatrix.mastery.questions.push(record.questionId);
            } else {
                metrics.confidenceMatrix.uncertain.count++;
                metrics.confidenceMatrix.uncertain.questions.push(record.questionId);
            }
        } else {
            if (record.confidence === 'high') {
                metrics.confidenceMatrix.danger.count++;
                metrics.confidenceMatrix.danger.questions.push(record.questionId);
            } else {
                metrics.confidenceMatrix.learning.count++;
                metrics.confidenceMatrix.learning.questions.push(record.questionId);
            }
        }
        
        if (!metrics.topicStats.has(record.topic)) {
            metrics.topicStats.set(record.topic, { correct: 0, total: 0, incorrectHighConfidence: 0, part: record.part, section: record.section });
        }
        const stats = metrics.topicStats.get(record.topic)!;
        stats.total++;
        if (record.isCorrect) {
            stats.correct++;
        } else if (record.confidence === 'high') {
            stats.incorrectHighConfidence++;
        }
    }

    const weakestTopics = Array.from(metrics.topicStats.entries())
        .map(([topic, stats]) => {
            const accuracy = stats.total > 0 ? stats.correct / stats.total : 0;
            const weaknessScore = (1 - accuracy) * stats.total + (stats.incorrectHighConfidence * 1.5);
            return { topic, weaknessScore, accuracy, total: stats.total, part: stats.part, section: stats.section };
        })
        .filter(t => t.total > 2)
        .sort((a, b) => b.weaknessScore - a.weaknessScore)
        .slice(0, 5);

    return {
        ...metrics,
        overallAccuracy: metrics.totalQuestions > 0 ? Math.round((metrics.totalCorrect / metrics.totalQuestions) * 100) : 0,
        weakestTopics,
        incorrectQuestions: answerHistory.filter(a => !a.isCorrect).map(a => a.questionId),
    };
};
