import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Prefer env from Vite, else fall back to hardcoded
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyA0QpGRnjw1xWHL6xFZUnE71XZ-_7cIDik",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "cma-compass-app.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "cma-compass-app",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "cma-compass-app.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "462756783791",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:462756783791:web:119a0e436b90dbe303965a",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
