import { db, auth } from './firebase';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { ExplainedConcept } from "../types";

const getUserId = (): string => {
    const user = auth.currentUser;
    if (!user) {
        throw new Error("No user is currently logged in. Cannot perform data operation.");
    }
    return user.uid;
};

export const loadExplainedConcepts = async (): Promise<ExplainedConcept[]> => {
    try {
        const userId = getUserId();
        const conceptsCol = collection(db, 'users', userId, 'explainedConcepts');
        const q = query(conceptsCol, orderBy('timestamp', 'desc'));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ExplainedConcept));
    } catch (error) {
        console.error("Failed to load explained concepts:", error);
        return [];
    }
};

export const addExplainedConcept = async (newConceptData: Omit<ExplainedConcept, 'id' | 'timestamp' | 'bookmarked'>): Promise<ExplainedConcept> => {
    const userId = getUserId();
    const conceptsCol = collection(db, 'users', userId, 'explainedConcepts');
    
    const newConcept: Omit<ExplainedConcept, 'id'> = {
        ...newConceptData,
        timestamp: new Date().toISOString(),
        bookmarked: false,
    };

    const docRef = await addDoc(conceptsCol, newConcept);
    return { ...newConcept, id: docRef.id };
};

export const toggleBookmark = async (conceptId: string): Promise<ExplainedConcept[]> => {
    const userId = getUserId();
    const concepts = await loadExplainedConcepts();
    const concept = concepts.find(c => c.id === conceptId);

    if (concept) {
        const conceptRef = doc(db, 'users', userId, 'explainedConcepts', conceptId);
        await updateDoc(conceptRef, { bookmarked: !concept.bookmarked });
    }
    return await loadExplainedConcepts();
};

export const deleteExplainedConcept = async (conceptId: string): Promise<ExplainedConcept[]> => {
    const userId = getUserId();
    const conceptRef = doc(db, 'users', userId, 'explainedConcepts', conceptId);
    await deleteDoc(conceptRef);
    return await loadExplainedConcepts();
};
