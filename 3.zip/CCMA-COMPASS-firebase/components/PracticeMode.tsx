import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Question, PracticeFilters, AppMode } from '../types';
import { recordAnswer, toggleFlaggedQuestion, recordSessionSummary, loadAnalytics, recordConfidence } from '../services/analyticsService';
import { ChevronLeftIcon, ChevronRightIcon, FlagIcon as FlagSolidIcon, StopCircleIcon, PlayIcon, PauseIcon, LightBulbIcon, InformationCircleIcon } from '@heroicons/react/24/solid';
import { FlagIcon as FlagOutlineIcon } from '@heroicons/react/24/outline';
import { useToast } from '../App';

const getShuffledQuestions = (bank: Question[], filters: PracticeFilters, answeredIds: string[]): { questions: Question[], usedSeenQuestions: boolean } => {
    let filtered = bank;
    if (filters.part !== 'All') {
         filtered = bank.filter(q => q.part === filters.part);
    }
    if (filters.section !== 'All') {
        filtered = filtered.filter(q => q.section === filters.section);
    }
     if (filters.topic && filters.topic !== 'All Topics') {
        filtered = filtered.filter(q => q.topic === filters.topic);
    }
    if (filters.type !== 'mixed') {
        filtered = filtered.filter(q => q.type === filters.type);
    }
    if (filters.difficulty !== 'mixed') {
        filtered = filtered.filter(q => q.difficulty === filters.difficulty);
    }

    const unseenQuestions = filtered.filter(q => !answeredIds.includes(q.id));
    const seenQuestions = filtered.filter(q => answeredIds.includes(q.id));

    const shuffledUnseen = unseenQuestions.sort(() => 0.5 - Math.random());

    if (shuffledUnseen.length >= filters.count) {
        return { questions: shuffledUnseen.slice(0, filters.count), usedSeenQuestions: false };
    }

    const needed = filters.count - shuffledUnseen.length;
    const shuffledSeen = seenQuestions.sort(() => 0.5 - Math.random());
    const combined = [...shuffledUnseen, ...shuffledSeen.slice(0, needed)];
    
    return { questions: combined.slice(0, filters.count), usedSeenQuestions: true };
};


const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

const ConfidenceRater: React.FC<{ questionId: string }> = ({ questionId }) => {
    const [rated, setRated] = useState(false);
    
    const handleRate = (level: 'low' | 'medium' | 'high') => {
        recordConfidence(questionId, level);
        setRated(true);
    };

    if (rated) {
        return <p className="text-center text-sm text-green-400 mt-3">Confidence recorded!</p>;
    }

    return (
        <div className="mt-4 text-center">
            <p className="text-sm text-gray-400 mb-2">How confident were you?</p>
            <div className="flex justify-center space-x-3">
                <button onClick={() => handleRate('low')} className="px-3 py-1 text-sm bg-red-800 hover:bg-red-700 rounded-md">Low</button>
                <button onClick={() => handleRate('medium')} className="px-3 py-1 text-sm bg-yellow-800 hover:bg-yellow-700 rounded-md">Medium</button>
                <button onClick={() => handleRate('high')} className="px-3 py-1 text-sm bg-green-800 hover:bg-green-700 rounded-md">High</button>
            </div>
        </div>
    );
}

const QuizSession: React.FC<{
    questions: Question[];
    onEndSession: () => void;
    onNavigate: (mode: AppMode, prefill?: any) => void;
    flaggedQuestions: string[];
    isTimed: boolean;
    showReviewingMessage: boolean;
}> = ({ questions, onEndSession, onNavigate, flaggedQuestions, isTimed, showReviewingMessage }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [userAnswers, setUserAnswers] = useState<(number | null)[]>(Array(questions.length).fill(null));
    const [questionTimers, setQuestionTimers] = useState<number[]>(Array(questions.length).fill(0));
    const [isFinished, setIsFinished] = useState(false);
    const [flagged, setFlagged] = useState<string[]>(flaggedQuestions);
    const [timeRemaining, setTimeRemaining] = useState(questions.length * 90); // 1.5 minutes per question
    const [isPaused, setIsPaused] = useState(false);

    const questionStartTimeRef = useRef<number>(Date.now());
    const timerIntervalRef = useRef<number | null>(null);

    const question = questions[currentIndex];
    const userAnswerIndex = userAnswers[currentIndex];
    const isAnswered = userAnswerIndex !== null;

    useEffect(() => {
        if (!isTimed || isPaused || isFinished) {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
            return;
        }
        timerIntervalRef.current = window.setInterval(() => {
            setTimeRemaining(prev => {
                if (prev <= 1) {
                    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
                    finishSession();
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
        return () => { if (timerIntervalRef.current) clearInterval(timerIntervalRef.current); };
    }, [isTimed, isPaused, isFinished]);

    const handleAnswerSelect = (choiceIndex: number) => {
        if (isAnswered) return;
        const timeTaken = (Date.now() - questionStartTimeRef.current) / 1000;
        const isCorrect = choiceIndex === question.answer.index;
        
        recordAnswer(question, isCorrect, timeTaken);
        
        const newAnswers = [...userAnswers];
        newAnswers[currentIndex] = choiceIndex;
        setUserAnswers(newAnswers);
        const newTimers = [...questionTimers];
        newTimers[currentIndex] = timeTaken;
        setQuestionTimers(newTimers);
    };
    
    const handleToggleFlag = () => {
        toggleFlaggedQuestion(question.id);
        setFlagged(prev => prev.includes(question.id) ? prev.filter(id => id !== question.id) : [...prev, question.id]);
    };

    const navigate = (direction: 'next' | 'prev') => {
        const newIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;
        if (newIndex >= 0 && newIndex < questions.length) {
            setCurrentIndex(newIndex);
            questionStartTimeRef.current = Date.now();
        }
    };
    
    const finishSession = () => {
        setIsFinished(true);
        const answeredCount = userAnswers.filter(a => a !== null).length;
        if (answeredCount > 0) {
            const correctAnswers = userAnswers.filter((answer, index) => answer !== null && answer === questions[index].answer.index).length;
            const totalTimeForAnswered = questionTimers.reduce((acc, time) => acc + time, 0);
            recordSessionSummary({
                accuracy: Math.round((correctAnswers / answeredCount) * 100),
                questionsAnswered: answeredCount,
                avgTimePerQuestion: parseFloat((totalTimeForAnswered / answeredCount).toFixed(1)),
            });
        }
        onEndSession();
    };
    
    const handleExplainConcept = () => {
        onNavigate('Explain', { concept: question.topic, context: question.question });
    };

    if (isFinished) return <div />;

    return (
        <div className="bg-gray-800 p-6 md:p-8 rounded-xl shadow-2xl animate-fade-in relative">
            {isPaused && (
                <div className="absolute inset-0 bg-black bg-opacity-70 flex flex-col justify-center items-center z-20 rounded-xl">
                    <h2 className="text-3xl font-bold text-white mb-4">Session Paused</h2>
                    <button onClick={() => setIsPaused(false)} className="flex items-center px-6 py-3 bg-cyan-600 text-white rounded-md font-semibold hover:bg-cyan-700">
                        <PlayIcon className="h-6 w-6 mr-2" /> Resume
                    </button>
                </div>
            )}
            
            {showReviewingMessage && (
                <div className="bg-yellow-900/50 text-yellow-300 text-sm p-2 rounded-md text-center mb-4">
                    You've seen all new questions for this topic! Reviewing some you've answered before.
                </div>
            )}

            <div className="flex justify-between items-center mb-4 border-b border-gray-700 pb-4">
                <div>
                    <h2 className="text-2xl font-bold text-cyan-400">Question {currentIndex + 1} / {questions.length}</h2>
                    <p className="text-sm text-gray-400">{question.part} - {question.section} - {question.topic}</p>
                </div>
                <div className="flex items-center space-x-4">
                    {isTimed && <div className={`text-lg font-mono px-3 py-1 rounded ${timeRemaining < 60 ? 'text-red-400 animate-pulse' : 'text-gray-300'}`}>{formatTime(timeRemaining)}</div>}
                    <button onClick={handleToggleFlag} className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300" title={flagged.includes(question.id) ? 'Unflag Question' : 'Flag Question'}>{flagged.includes(question.id) ? <FlagSolidIcon className="h-6 w-6" /> : <FlagOutlineIcon className="h-6 w-6" />}</button>
                    <button onClick={finishSession} className="flex items-center space-x-2 text-red-400 hover:text-red-300" title="End Session"><StopCircleIcon className="h-6 w-6" /></button>
                </div>
            </div>

            <div className="my-6 min-h-[6rem]"><p className="text-lg text-gray-200 leading-relaxed">{question.question}</p></div>

            <div className="space-y-3">
                {question.choices.map((choice, index) => {
                    let choiceClass = "bg-gray-700 hover:bg-gray-600";
                    if (isAnswered) {
                         if (index === question.answer.index) choiceClass = "bg-green-800 border-green-600";
                         else if (index === userAnswerIndex) choiceClass = "bg-red-800 border-red-600";
                         else choiceClass = "bg-gray-800 opacity-60";
                    }
                    return (
                        <button key={index} disabled={isAnswered} onClick={() => handleAnswerSelect(index)} className={`w-full text-left p-4 rounded-lg border border-transparent transition-all duration-300 ${choiceClass} ${!isAnswered ? 'cursor-pointer' : 'cursor-default'}`}>
                            <span className="font-mono mr-3">{String.fromCharCode(65 + index)}.</span> {choice}
                        </button>
                    );
                })}
            </div>

            {isAnswered && (
                <div className="mt-6 p-4 bg-gray-900 rounded-lg animate-fade-in">
                    <div className="flex justify-between items-center">
                        <h3 className="font-bold text-yellow-300">Explanation</h3>
                        <button onClick={handleExplainConcept} className="flex items-center text-xs px-3 py-1 bg-cyan-800 text-cyan-200 rounded-md hover:bg-cyan-700">
                            <LightBulbIcon className="h-4 w-4 mr-1"/> Explain this concept further
                        </button>
                    </div>
                    <p className="text-gray-300 mt-2">{question.answer.explanation}</p>
                    <ConfidenceRater questionId={question.id} />
                </div>
            )}
            
            <div className="flex justify-between items-center mt-8 pt-4 border-t border-gray-700">
                <button onClick={() => navigate('prev')} disabled={currentIndex === 0} className="flex items-center px-4 py-2 bg-gray-700 rounded-md disabled:opacity-50 disabled:cursor-not-allowed"><ChevronLeftIcon className="h-5 w-5 mr-2" /> Prev</button>
                 {isTimed && !isFinished && (<button onClick={() => setIsPaused(true)} className="flex items-center px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700"><PauseIcon className="h-5 w-5 mr-2" /> Pause</button>)}
                 {isAnswered && currentIndex < questions.length - 1 ? (
                    <button onClick={() => navigate('next')} className="flex items-center px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700">Next <ChevronRightIcon className="h-5 w-5 ml-2" /></button>
                 ) : (
                     <button onClick={finishSession} className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Finish Session</button>
                 )}
            </div>
        </div>
    );
};

interface PracticeModeProps {
    questionBank: Question[];
    onNavigate: (mode: AppMode, prefill?: any) => void;
    prefilledFilters: Partial<PracticeFilters> | null;
}

export const PracticeMode: React.FC<PracticeModeProps> = ({ questionBank, onNavigate, prefilledFilters }) => {
    const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
    const [isSessionActive, setIsSessionActive] = useState(false);
    const [isTimed, setIsTimed] = useState(false);
    const [showReviewingMessage, setShowReviewingMessage] = useState(false);
    
    const initialFilters: PracticeFilters = { part: 'Part 1', section: 'All', count: 10, type: 'mixed', difficulty: 'mixed' };
    const [filters, setFilters] = useState<PracticeFilters>(initialFilters);
    const [flaggedQuestions, setFlaggedQuestions] = useState<string[]>([]);
    const [curriculum, setCurriculum] = useState<any>(null);
    const showToast = useToast();

    useEffect(() => {
        const fetchAnalytics = async () => {
            const analytics = await loadAnalytics();
            setFlaggedQuestions(analytics.flaggedQuestions || []);
        };
        fetchAnalytics();
    }, [isSessionActive]);
    
    useEffect(() => {
        if (prefilledFilters) {
            setFilters(prev => ({...prev, ...prefilledFilters}));
        }
    }, [prefilledFilters]);

    useEffect(() => {
        fetch('/data/cma_curriculum.json')
            .then(res => res.json())
            .then(data => setCurriculum(data))
            .catch(err => {
                console.error("Failed to load curriculum:", err);
            });
    }, []);

    const availableSections = useMemo(() => {
        if (!curriculum) {
            // Fallback to old method while loading or if fetch fails
            const sections = new Set(questionBank.filter(q => q.part === filters.part).map(q => q.section));
            return [{ value: 'All', label: 'All Sections' }, ...Array.from(sections).sort().map(s => ({ value: s, label: s }))];
        }
        
        const partData = curriculum[filters.part];
        if (!partData || !Array.isArray(partData)) return [{ value: 'All', label: 'All Sections' }];

        const sections = partData.map((section: any, index: number) => {
            const sectionLetter = String.fromCharCode(65 + index); // A, B, C...
            return {
                value: `Sec ${sectionLetter}`, // The value used for filtering, e.g., "Sec C"
                label: section.name            // The value for display, e.g., "Decision Analysis"
            };
        });

        return [{ value: 'All', label: 'All Sections' }, ...sections];
    }, [curriculum, filters.part, questionBank]);

    useEffect(() => {
        if (!availableSections.some(s => s.value === filters.section)) {
            setFilters(f => ({ ...f, section: 'All'}));
        }
    }, [availableSections, filters.section]);

    const handleStartSession = async (e: React.FormEvent) => {
        e.preventDefault();
        const { answerHistory } = await loadAnalytics();
        const answeredIds = [...new Set(answerHistory.map(a => a.questionId))];
        const { questions, usedSeenQuestions } = getShuffledQuestions(questionBank, filters, answeredIds);
        if (questions.length > 0) {
            setSessionQuestions(questions);
            setShowReviewingMessage(usedSeenQuestions && questions.length === filters.count);
            setIsSessionActive(true);
        } else {
            showToast("No questions found matching your criteria. Please broaden your filters.", 'error');
        }
    };

    const handleEndSession = () => setIsSessionActive(false);
    
    if (isSessionActive) {
        return <QuizSession questions={sessionQuestions} onEndSession={handleEndSession} onNavigate={onNavigate} flaggedQuestions={flaggedQuestions} isTimed={isTimed} showReviewingMessage={showReviewingMessage} />;
    }

    return (
        <div className="max-w-xl mx-auto">
            <form onSubmit={handleStartSession} className="bg-gray-800 p-8 rounded-xl shadow-2xl animate-fade-in">
                <h2 className="text-3xl font-bold text-cyan-400 mb-6">Setup Practice Session</h2>
                
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Part</label>
                        <select value={filters.part} onChange={e => setFilters(p => ({...p, part: e.target.value as 'Part 1' | 'Part 2'}))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                           <option>Part 1</option><option>Part 2</option>
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Section</label>
                        <select value={filters.section} onChange={e => setFilters(p => ({...p, section: e.target.value}))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                            {availableSections.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Question Type</label>
                        <select value={filters.type} onChange={e => setFilters(p => ({...p, type: e.target.value as any}))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                            <option value="mixed">Mixed</option><option value="theory">Theory</option><option value="problem">Problem</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Difficulty</label>
                        <select value={filters.difficulty} onChange={e => setFilters(p => ({...p, difficulty: e.target.value as any}))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                            <option value="mixed">Mixed</option><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                        </select>
                    </div>
                     <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-300 mb-1">Number of Questions ({filters.count})</label>
                         <input type="range" min="5" max="50" step="5" value={filters.count} onChange={e => setFilters(p => ({...p, count: parseInt(e.target.value, 10)}))} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                    </div>
                </div>

                <div className="mt-6 flex items-center justify-center group relative">
                    <label htmlFor="timed-mode-toggle" className="flex items-center cursor-pointer">
                        <span className="mr-3 text-gray-300 font-medium">Exam Simulation (Timed Mode)</span>
                        <InformationCircleIcon className="h-5 w-5 text-gray-500" />
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-gray-700 text-white text-xs rounded py-1 px-2 text-center opacity-0 group-hover:opacity-100 transition-opacity">
                            1.5 minutes per question
                        </div>
                    </label>
                    <div className="relative ml-3">
                        <input type="checkbox" id="timed-mode-toggle" className="sr-only" checked={isTimed} onChange={() => setIsTimed(!isTimed)} />
                        <div className={`block ${isTimed ? 'bg-cyan-600' : 'bg-gray-600'} w-14 h-8 rounded-full`}></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition-transform ${isTimed ? 'transform translate-x-6' : ''}`}></div>
                    </div>
                </div>

                 <button type="submit" className="w-full mt-8 bg-cyan-600 text-white font-bold py-3 rounded-lg hover:bg-cyan-700 transition-colors text-lg">
                    Start Session
                </button>
            </form>
        </div>
    );
};
