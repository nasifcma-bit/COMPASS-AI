import React, { useState, useEffect, useMemo } from 'react';
import { AppMode, PracticeFilters, AnalyticsData } from '../types';
import { loadAnalytics, calculatePerformanceMetrics } from '../services/analyticsService';
import { Spinner } from './Spinner';
import { ChevronDownIcon, BookOpenIcon, BeakerIcon } from '@heroicons/react/24/outline';

interface CurriculumModeProps {
    onNavigate: (mode: AppMode, prefill?: any) => void;
}

const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 80) return 'text-green-400';
    if (accuracy >= 60) return 'text-yellow-400';
    return 'text-red-400';
};

export const CurriculumMode: React.FC<CurriculumModeProps> = ({ onNavigate }) => {
    const [curriculum, setCurriculum] = useState<any>(null);
    const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedPart, setSelectedPart] = useState<'Part 1' | 'Part 2'>('Part 1');
    const [expandedSections, setExpandedSections] = useState<string[]>([]);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [curriculumRes, analyticsData] = await Promise.all([
                    fetch('/data/cma_curriculum.json'),
                    loadAnalytics()
                ]);
                const curriculumData = await curriculumRes.json();
                setCurriculum(curriculumData);
                setAnalytics(analyticsData);
            } catch (error) {
                console.error("Failed to load curriculum or analytics data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const topicStats = useMemo(() => {
        if (!analytics) return new Map();
        const metrics = calculatePerformanceMetrics(analytics.answerHistory);
        return metrics.topicStats;
    }, [analytics]);

    const handleToggleSection = (sectionName: string) => {
        setExpandedSections(prev =>
            prev.includes(sectionName)
                ? prev.filter(name => name !== sectionName)
                : [...prev, sectionName]
        );
    };

    const handlePractice = (sectionName: string, topicName: string) => {
        const sectionMap: { [key:string]: string } = {};
        if (curriculum) {
            curriculum[selectedPart].forEach((section: any, index: number) => {
                const sectionLetter = String.fromCharCode(65 + index);
                sectionMap[section.name] = `Sec ${sectionLetter}`;
            });
        }
        
        const prefill: Partial<PracticeFilters> = {
            part: selectedPart,
            section: sectionMap[sectionName] || sectionName,
            topic: topicName,
            count: 10,
        };
        onNavigate('Practice', prefill);
    };

    const handleExplain = (topicName: string) => {
        onNavigate('Explain', { concept: topicName, context: `Explain the CMA topic: ${topicName}` });
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-[50vh]">
                <Spinner />
            </div>
        );
    }
    
    if (!curriculum) {
        return <div className="text-center text-red-400">Failed to load curriculum data.</div>;
    }

    const partData = curriculum[selectedPart];

    return (
        <div className="max-w-4xl mx-auto animate-fade-in space-y-8">
            <div className="bg-gray-800 p-6 rounded-xl shadow-2xl">
                <h2 className="text-3xl font-bold text-cyan-400 mb-4">Curriculum Explorer</h2>
                <div className="flex border-b border-gray-700">
                    <button onClick={() => setSelectedPart('Part 1')} className={`px-6 py-3 text-lg font-semibold ${selectedPart === 'Part 1' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400 hover:text-white'}`}>Part 1</button>
                    <button onClick={() => setSelectedPart('Part 2')} className={`px-6 py-3 text-lg font-semibold ${selectedPart === 'Part 2' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400 hover:text-white'}`}>Part 2</button>
                </div>
            </div>

            <div className="space-y-4">
                {partData.map((section: any) => {
                    const isExpanded = expandedSections.includes(section.name);
                    return (
                        <div key={section.name} className="bg-gray-800 rounded-xl shadow-lg">
                            <button onClick={() => handleToggleSection(section.name)} className="w-full flex justify-between items-center p-6 text-left">
                                <h3 className="text-xl font-bold text-gray-200">{section.name} <span className="text-sm font-normal text-gray-400">({section.weight})</span></h3>
                                <ChevronDownIcon className={`h-6 w-6 text-gray-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                            </button>
                            {isExpanded && (
                                <div className="px-6 pb-6 border-t border-gray-700 animate-fade-in">
                                    {section.topics.map((topic: any) => {
                                        const stats = topicStats.get(topic.name);
                                        const accuracy = stats && stats.total > 0 ? Math.round((stats.correct / stats.total) * 100) : null;
                                        return (
                                            <div key={topic.name} className="py-4 border-b border-gray-700 last:border-b-0 flex justify-between items-center flex-wrap gap-2">
                                                <div>
                                                    <p className="font-semibold text-gray-300">{topic.name}</p>
                                                    {accuracy !== null ? (
                                                        <p className={`text-sm font-bold ${getAccuracyColor(accuracy)}`}>
                                                            {accuracy}% correct <span className="text-xs text-gray-500 font-normal">({stats?.total} Qs)</span>
                                                        </p>
                                                    ) : (
                                                        <p className="text-xs text-gray-500">No practice data yet</p>
                                                    )}
                                                </div>
                                                <div className="flex space-x-2">
                                                    <button onClick={() => handleExplain(topic.name)} title="Explain Topic" className="p-2 text-gray-300 bg-gray-700 hover:bg-gray-600 rounded-md flex items-center text-sm">
                                                        <BeakerIcon className="h-4 w-4 mr-1" /> Explain
                                                    </button>
                                                    <button onClick={() => handlePractice(section.name, topic.name)} title="Practice Topic" className="p-2 text-white bg-cyan-700 hover:bg-cyan-600 rounded-md flex items-center text-sm">
                                                        <BookOpenIcon className="h-4 w-4 mr-1" /> Practice
                                                    </button>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
