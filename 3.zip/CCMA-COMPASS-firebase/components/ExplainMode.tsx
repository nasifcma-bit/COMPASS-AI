import React, { useState, useEffect, useMemo } from 'react';
import { explainConcept, generateQuestionsForConcept } from '../services/geminiService';
import { loadExplainedConcepts, addExplainedConcept, toggleBookmark, deleteExplainedConcept } from '../services/explanationService';
import { Spinner } from './Spinner';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Question, ExplainedConcept } from '../types';
import { useToast } from '../App';
import { DocumentDuplicateIcon, ArrowDownTrayIcon, PrinterIcon, BookmarkIcon, TrashIcon, SparklesIcon, ChevronLeftIcon, FaceSmileIcon, AcademicCapIcon, Cog6ToothIcon, BeakerIcon } from '@heroicons/react/24/outline';
import { BookmarkIcon as BookmarkSolidIcon } from '@heroicons/react/24/solid';

const GeneratedQuestion: React.FC<{ question: Question }> = ({ question }) => (
    <div className="bg-gray-900 p-4 rounded-lg border border-gray-700 mb-4">
        <p className="font-semibold mt-2">{question.question}</p>
        <ul className="list-disc list-inside mt-2 space-y-1 text-sm text-gray-300">
            {question.choices.map((c, i) => (
                <li key={i} className={i === question.answer.index ? 'text-green-400 font-bold' : ''}>{c}</li>
            ))}
        </ul>
    </div>
);

const ExplanationCard: React.FC<{ 
    concept: ExplainedConcept; 
    onGenerateQs: (concept: string) => void;
    isGeneratingQs: boolean;
}> = ({ concept, onGenerateQs, isGeneratingQs }) => {
    const showToast = useToast();

    const handleCopyToClipboard = () => {
        navigator.clipboard.writeText(concept.explanation)
            .then(() => showToast('Copied to clipboard!', 'success'))
            .catch(() => showToast('Failed to copy text.', 'error'));
    };

    const handleDownloadMD = () => {
        const blob = new Blob([concept.explanation], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${concept.concept.replace(/\s+/g, '_')}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handlePrint = () => {
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            printWindow.document.write(`
                <html><head><title>${concept.concept}</title>
                <style>body { font-family: sans-serif; line-height: 1.6; } h3 { border-bottom: 1px solid #ccc; padding-bottom: 5px; } code { background-color: #f4f4f4; padding: 2px 5px; border-radius: 4px; }</style>
                </head><body>
                    <h1>${concept.concept}</h1>
                    ${concept.explanation.replace(/### (.*)/g, '<h3>$1</h3>').replace(/\n/g, '<br/>')}
                </body></html>
            `);
            printWindow.document.close();
            printWindow.print();
        }
    };

    return (
        <div className="bg-gray-800 p-8 rounded-xl shadow-2xl animate-fade-in">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-2xl font-bold text-cyan-400">{concept.concept}</h3>
                    <p className="text-xs text-gray-500">Explained on {new Date(concept.timestamp).toLocaleDateString()}</p>
                </div>
                <div className="flex space-x-2">
                    <button onClick={handleCopyToClipboard} title="Copy" className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full"><DocumentDuplicateIcon className="h-5 w-5"/></button>
                    <button onClick={handleDownloadMD} title="Download Markdown" className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full"><ArrowDownTrayIcon className="h-5 w-5"/></button>
                    <button onClick={handlePrint} title="Print" className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full"><PrinterIcon className="h-5 w-5"/></button>
                </div>
            </div>
            
            <div className="prose prose-invert max-w-none text-gray-300 mt-6">
                 <ReactMarkdown remarkPlugins={[remarkGfm]}>{concept.explanation}</ReactMarkdown>
            </div>
            
            <div className="mt-8 border-t border-gray-700 pt-6">
                <h4 className="text-xl font-bold text-cyan-400 mb-4">Turn Learning into Practice</h4>
                <button onClick={() => onGenerateQs(concept.concept)} disabled={isGeneratingQs} className="bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-500 flex items-center justify-center">
                    {isGeneratingQs ? <Spinner/> : `Generate 3 Practice Questions on "${concept.concept}"`}
                </button>
            </div>
        </div>
    );
};

type ExplanationType = "ELI5" | "Formal Definition" | "How It Works" | "Practical Example" | "CMA Exam Pro-Tip";

const EXPLANATION_TYPE_CONFIG: { id: ExplanationType; label: string; icon: React.FC<React.ComponentProps<'svg'>> }[] = [
    { id: "ELI5", label: "ELI5", icon: FaceSmileIcon },
    { id: "Formal Definition", label: "Definition", icon: AcademicCapIcon },
    { id: "How It Works", label: "How it Works", icon: Cog6ToothIcon },
    { id: "Practical Example", label: "Example", icon: BeakerIcon },
    { id: "CMA Exam Pro-Tip", label: "Pro-Tip", icon: SparklesIcon },
];

const allExplanationTypes = EXPLANATION_TYPE_CONFIG.map(t => t.id);

interface ExplainModeProps {
  onAddToBank: (questions: Question[]) => Promise<{ added: number, duplicates: number }>;
  prefill: { concept: string; context: string } | null;
}

export const ExplainMode: React.FC<ExplainModeProps> = ({ onAddToBank, prefill }) => {
    const [conceptInput, setConceptInput] = useState('');
    const [contextInput, setContextInput] = useState('');
    
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const [practiceQuestions, setPracticeQuestions] = useState<Question[]>([]);
    const [isGeneratingQs, setIsGeneratingQs] = useState(false);
    const [qError, setQError] = useState<string | null>(null);
    
    const [explainedConcepts, setExplainedConcepts] = useState<ExplainedConcept[]>([]);
    const [activeConcept, setActiveConcept] = useState<ExplainedConcept | null>(null);
    const [sidebarView, setSidebarView] = useState<'history' | 'bookmarks'>('history');
    const [selectedTypes, setSelectedTypes] = useState<ExplanationType[]>(allExplanationTypes);

    const showToast = useToast();
    
    useEffect(() => {
        const fetchConcepts = async () => {
            const concepts = await loadExplainedConcepts();
            setExplainedConcepts(concepts);
        };
        fetchConcepts();
    }, []);

    useEffect(() => {
        if (prefill) {
            setConceptInput(prefill.concept);
            setContextInput(prefill.context);
            setActiveConcept(null); // Clear active concept to show the form
        }
    }, [prefill]);

    const handleToggleType = (type: ExplanationType) => {
        setSelectedTypes(prev =>
            prev.includes(type)
                ? prev.filter(t => t !== type)
                : [...prev, type]
        );
    };

    const handleExplain = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!conceptInput.trim()) {
            setError('Please enter a concept to explain.'); return;
        }
        if (selectedTypes.length === 0) {
            showToast('Please select at least one explanation type.', 'error');
            return;
        }
        setIsLoading(true); setError(null); setPracticeQuestions([]); setQError(null);

        try {
            const explanationText = await explainConcept(conceptInput, contextInput, selectedTypes);
            const newSavedConcept = await addExplainedConcept({ concept: conceptInput, context: contextInput, explanation: explanationText });
            setExplainedConcepts(prev => [newSavedConcept, ...prev]);
            setActiveConcept(newSavedConcept);
            setConceptInput(''); setContextInput('');
        } catch (err: any) {
            setError(err.message || 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleGeneratePractice = async (conceptForQs: string) => {
        setIsGeneratingQs(true); setQError(null); setPracticeQuestions([]);
        try {
            const questions = await generateQuestionsForConcept(conceptForQs, 3);
            setPracticeQuestions(questions);
        } catch (err: any) {
            setQError(err.message || "Failed to generate questions.");
        } finally {
            setIsGeneratingQs(false);
        }
    };

    const handleAddToBank = async () => {
        const { added, duplicates } = await onAddToBank(practiceQuestions);
        showToast(`Success! Added ${added} new question(s). ${duplicates > 0 ? `${duplicates} were duplicates.` : ''}`, 'success');
        setPracticeQuestions([]);
    };

    const handleToggleBookmark = async (e: React.MouseEvent, conceptId: string) => {
        e.stopPropagation();
        const updatedConcepts = await toggleBookmark(conceptId);
        setExplainedConcepts(updatedConcepts);
        if (activeConcept?.id === conceptId) {
            setActiveConcept(c => c ? { ...c, bookmarked: !c.bookmarked } : null);
        }
    };

    const handleDeleteConcept = async (e: React.MouseEvent, conceptId: string) => {
        e.stopPropagation();
        const updatedConcepts = await deleteExplainedConcept(conceptId);
        setExplainedConcepts(updatedConcepts);
        if (activeConcept?.id === conceptId) {
            setActiveConcept(null);
        }
    };
    
    const filteredConcepts = useMemo(() => {
        return sidebarView === 'bookmarks' 
            ? explainedConcepts.filter(c => c.bookmarked)
            : explainedConcepts;
    }, [sidebarView, explainedConcepts]);
    
    const handleClearActive = () => {
        setActiveConcept(null);
        setConceptInput('');
        setContextInput('');
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <aside className="md:col-span-1 lg:col-span-1 bg-gray-800 p-4 rounded-xl shadow-lg h-full">
                <h2 className="text-xl font-bold text-cyan-400 mb-4">My Library</h2>
                <div className="flex border-b border-gray-700 mb-2">
                    <button onClick={() => setSidebarView('history')} className={`flex-1 pb-2 text-sm font-semibold ${sidebarView === 'history' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400'}`}>History</button>
                    <button onClick={() => setSidebarView('bookmarks')} className={`flex-1 pb-2 text-sm font-semibold ${sidebarView === 'bookmarks' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400'}`}>Bookmarks</button>
                </div>
                <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                    {filteredConcepts.map(c => (
                        <div key={c.id} onClick={() => setActiveConcept(c)} className={`p-3 rounded-md cursor-pointer group ${activeConcept?.id === c.id ? 'bg-cyan-900/50' : 'hover:bg-gray-700'}`}>
                            <div className="flex justify-between items-start">
                                <p className="font-semibold text-sm text-gray-200 flex-1 truncate pr-2">{c.concept}</p>
                                <div className="flex items-center space-x-1">
                                    <button onClick={(e) => handleToggleBookmark(e, c.id)} className="text-gray-500 hover:text-yellow-400">
                                        {c.bookmarked ? <BookmarkSolidIcon className="h-4 w-4 text-yellow-400"/> : <BookmarkIcon className="h-4 w-4"/>}
                                    </button>
                                    <button onClick={(e) => handleDeleteConcept(e, c.id)} className="text-gray-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <TrashIcon className="h-4 w-4"/>
                                    </button>
                                </div>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">{new Date(c.timestamp).toLocaleDateString()}</p>
                        </div>
                    ))}
                    {filteredConcepts.length === 0 && (
                        <p className="text-center text-gray-500 text-sm p-4">
                            {sidebarView === 'history' ? 'Your explained concepts will appear here.' : 'Your bookmarked concepts will appear here.'}
                        </p>
                    )}
                </div>
            </aside>

            {/* Main Content */}
            <main className="md:col-span-2 lg:col-span-3 space-y-8">
                 {activeConcept ? (
                    <>
                        <button onClick={handleClearActive} className="flex items-center text-sm text-cyan-400 hover:underline mb-[-1rem]">
                            <ChevronLeftIcon className="h-4 w-4 mr-1"/> Back to Explainer
                        </button>
                        <ExplanationCard 
                            concept={activeConcept}
                            onGenerateQs={handleGeneratePractice}
                            isGeneratingQs={isGeneratingQs}
                        />
                    </>
                ) : (
                    <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                        <h2 className="text-3xl font-bold text-cyan-400 mb-2">Concept Explainer</h2>
                        <p className="text-gray-400 mb-6">Stuck on a topic? Get a clear, structured explanation from the AI tutor.</p>
                        <form onSubmit={handleExplain} className="space-y-6">
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">Explanation Style</label>
                                <div className="flex flex-wrap gap-2">
                                    {EXPLANATION_TYPE_CONFIG.map(({ id, label, icon: Icon }) => (
                                        <button
                                            type="button"
                                            key={id}
                                            onClick={() => handleToggleType(id)}
                                            className={`flex items-center space-x-2 px-3 py-2 text-xs font-medium rounded-full transition-colors ${
                                                selectedTypes.includes(id)
                                                    ? 'bg-cyan-600 text-white'
                                                    : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                                            }`}
                                        >
                                            <Icon className="h-4 w-4" />
                                            <span>{label}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                            <div>
                                <label htmlFor="concept" className="block text-sm font-medium text-gray-300 mb-1">Concept or Term</label>
                                <input id="concept" type="text" value={conceptInput} onChange={(e) => setConceptInput(e.target.value)} placeholder="e.g., 'Activity-Based Costing'" className="w-full bg-gray-700 border-gray-600 rounded-md p-3 text-lg" required />
                            </div>
                            <div>
                                <label htmlFor="context" className="block text-sm font-medium text-gray-300 mb-1">Specific Question or Context (Optional)</label>
                                <textarea id="context" value={contextInput} onChange={(e) => setContextInput(e.target.value)} rows={3} placeholder="e.g., 'How is it different from traditional costing?'" className="w-full bg-gray-700 border-gray-600 rounded-md p-3" />
                            </div>
                            <button type="submit" disabled={isLoading} className="w-full bg-cyan-600 text-white font-bold py-3 rounded-lg hover:bg-cyan-700 transition-colors disabled:bg-gray-500 flex items-center justify-center text-lg">
                                {isLoading ? <Spinner /> : 'Explain It To Me'}
                            </button>
                            {error && <p className="text-red-400 text-sm mt-4 text-center">{error}</p>}
                        </form>
                    </div>
                )}

                {(isGeneratingQs || practiceQuestions.length > 0 || qError) && activeConcept && (
                    <div className="bg-gray-800 p-8 rounded-xl shadow-2xl animate-fade-in">
                        <h4 className="text-xl font-bold text-cyan-400 mb-4">Practice Questions</h4>
                        {isGeneratingQs && <div className="flex flex-col items-center justify-center h-24"><Spinner /><p className="mt-2 text-gray-400">Generating...</p></div>}
                        {practiceQuestions.length > 0 && (
                            <div>
                                {practiceQuestions.map((q) => <GeneratedQuestion key={q.id} question={q} />)}
                                <button onClick={handleAddToBank} className="bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-colors">
                                    Add to My Question Bank
                                </button>
                            </div>
                        )}
                        {qError && <p className="text-red-400 text-sm mt-4">{qError}</p>}
                    </div>
                )}
            </main>
        </div>
    );
};
