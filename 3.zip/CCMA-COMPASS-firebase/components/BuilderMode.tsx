import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Question } from '../types';
import { unlockBuilderBadge } from '../services/analyticsService';
import { generateQuestions } from '../services/geminiService';
import { transformRawQuestions } from '../services/questionService';
import { PlusCircleIcon, SparklesIcon, DocumentPlusIcon, ArrowUpTrayIcon, PencilSquareIcon, TrashIcon } from '@heroicons/react/24/outline';
import { Spinner } from './Spinner';
import { useToast } from '../App';


const emptyQuestion: Omit<Question, 'id' | 'source'> = {
    part: 'Part 1',
    section: '',
    topic: '',
    question: '',
    choices: ['', '', '', ''],
    answer: {
        index: 0,
        explanation: '',
    },
    difficulty: 'medium',
    type: 'theory',
};

interface BuilderModeProps {
    userQuestions: Question[];
    // FIX: The onAddToBank prop is asynchronous, so it should return a Promise.
    onAddToBank: (questions: Question[]) => Promise<{ added: number, duplicates: number }>;
    onDeleteQuestion: (questionId: string) => void;
    onUpdateQuestion: (question: Question) => void;
}

export const BuilderMode: React.FC<BuilderModeProps> = ({ userQuestions, onAddToBank, onDeleteQuestion, onUpdateQuestion }) => {
    const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
    const [newQuestion, setNewQuestion] = useState<Omit<Question, 'id' | 'source'>>(emptyQuestion);
    
    // State for AI generator
    const [aiPart, setAiPart] = useState<'Part 1' | 'Part 2'>('Part 1');
    const [aiSection, setAiSection] = useState<string>('');
    const [aiTopic, setAiTopic] = useState<string>('All Topics');
    const [aiCount, setAiCount] = useState<number>(3);
    const [aiDifficulty, setAiDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
    const [aiType, setAiType] = useState<'theory' | 'problem'>('theory');

    const [isGenerating, setIsGenerating] = useState(false);
    const [aiError, setAiError] = useState<string | null>(null);
    const [generatedQuestions, setGeneratedQuestions] = useState<Question[]>([]);
    
    const [curriculum, setCurriculum] = useState<any>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);
    const showToast = useToast();
    const topOfFormRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        fetch('/data/cma_curriculum.json')
            .then(res => res.json())
            .then(data => setCurriculum(data))
            .catch(err => {
                console.error("Failed to load curriculum:", err);
                setAiError("Could not load curriculum data. AI features may be limited.");
            });
    }, []);

    const availableSections = useMemo(() => {
        if (!curriculum) return [];
        return curriculum[aiPart].map((section: any) => section.name);
    }, [aiPart, curriculum]);
    
    const availableTopics = useMemo(() => {
        if (!curriculum) return ['All Topics'];
        const sectionData = curriculum[aiPart].find((s: any) => s.name === aiSection);
        if (sectionData && sectionData.topics) {
            return ['All Topics', ...sectionData.topics.map((t: any) => t.name)];
        }
        return ['All Topics'];
    }, [aiPart, aiSection, curriculum]);

    useEffect(() => {
        if (availableSections.length > 0 && !availableSections.includes(aiSection)) {
            setAiSection(availableSections[0]);
        }
    }, [aiPart, availableSections, aiSection]);

    useEffect(() => {
        setAiTopic('All Topics');
    }, [aiSection]);


    const myQuestions = useMemo(() => userQuestions.filter(q => q.source === 'user').reverse(), [userQuestions]);

    const handleInputChange = (field: keyof Omit<Question, 'id' | 'choices' | 'answer' | 'source'>, value: string) => {
        setNewQuestion(prev => ({ ...prev, [field]: value }));
    };
    const handleChoiceChange = (index: number, value: string) => {
        const updatedChoices = [...newQuestion.choices];
        updatedChoices[index] = value;
        setNewQuestion(prev => ({ ...prev, choices: updatedChoices }));
    };
    const handleAnswerChange = (field: 'index' | 'explanation', value: string | number) => {
        setNewQuestion(prev => ({ ...prev, answer: { ...prev.answer, [field]: value } }));
    };
    const handleCancelEdit = () => {
        setEditingQuestion(null);
        setNewQuestion(emptyQuestion);
    };

    // FIX: The function must be async to await the onAddToBank call.
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newQuestion.section.trim() || !newQuestion.topic.trim() || !newQuestion.question.trim() || !newQuestion.answer.explanation.trim()) {
            showToast("Please fill out all required fields.", 'error'); return;
        }
        if (newQuestion.choices.some(c => !c.trim())) {
            showToast("Please provide text for all four choices.", 'error'); return;
        }
        
        if (editingQuestion) {
            onUpdateQuestion({ ...editingQuestion, ...newQuestion });
            setEditingQuestion(null);
        } else {
            const questionToAdd: Question = { ...newQuestion, id: `user-${new Date().toISOString()}-${Math.random()}`, source: 'user' };
            // FIX: Await the asynchronous onAddToBank call.
            const { added } = await onAddToBank([questionToAdd]);
            if (added > 0) {
                unlockBuilderBadge();
                showToast("Question successfully added!", 'success');
            } else {
                showToast("This question appears to be a duplicate.", 'error');
            }
        }
        setNewQuestion(emptyQuestion);
    };
    
    const handleGenerate = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsGenerating(true); setAiError(null); setGeneratedQuestions([]);
        if (!aiSection) {
            setAiError("Please select a valid Section."); setIsGenerating(false); return;
        }
        try {
            const questions = await generateQuestions(aiPart, aiSection, aiTopic, aiCount, aiDifficulty, aiType);
            setGeneratedQuestions(questions);
        } catch (err: any) {
            setAiError(err.message || 'An unknown error occurred.');
        } finally {
            setIsGenerating(false);
        }
    };
    
    // FIX: The function must be async to await the onAddToBank call.
    const handleAddFromAI = async (questionsToAdd: Question[]) => {
        const questionsWithSource = questionsToAdd.map(q => ({ ...q, source: 'user' as const }));
        // FIX: Await the asynchronous onAddToBank call.
        const { added, duplicates } = await onAddToBank(questionsWithSource);
        if (added > 0) unlockBuilderBadge();
        showToast(`Added ${added} new question(s). ${duplicates > 0 ? `${duplicates} were duplicates.` : ''}`, 'success');
    };

    const handleAddSingleToBank = (questionId: string) => {
        const questionToAdd = generatedQuestions.find(q => q.id === questionId);
        if (questionToAdd) {
            handleAddFromAI([questionToAdd]);
            setGeneratedQuestions(prev => prev.filter(q => q.id !== questionId));
        }
    };

    const handleAddAllToBank = () => {
        if (generatedQuestions.length === 0) return;
        handleAddFromAI(generatedQuestions);
        setGeneratedQuestions([]);
    };
    
    const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (e) => {
            const text = e.target?.result;
            if (typeof text !== 'string') {
                showToast('Error: Could not read file content.', 'error'); return;
            }
            try {
                const jsonData = JSON.parse(text);
                const questions = transformRawQuestions(jsonData, 'import');
                if (questions.length === 0) {
                    showToast('Warning: No valid questions could be parsed from the file.', 'error'); return;
                }
                // FIX: Await the asynchronous onAddToBank call.
                const { added, duplicates } = await onAddToBank(questions);
                if (added > 0) unlockBuilderBadge();
                showToast(`Success! Imported ${added} new question(s). ${duplicates > 0 ? `${duplicates} were duplicates.` : ''}`, 'success');
            } catch (err) {
                console.error("File import error:", err);
                showToast('Error: Failed to parse JSON file. Please ensure it is correctly formatted.', 'error');
            }
        };
        reader.onerror = () => { showToast('Error reading file.', 'error'); };
        reader.readAsText(file);
        event.target.value = '';
    };

    const handleEditClick = (question: Question) => {
        setEditingQuestion(question);
        setNewQuestion(question);
        topOfFormRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in space-y-12">
            <div className="bg-gray-800 p-6 rounded-xl shadow-2xl" ref={topOfFormRef}>
                <h2 className="text-2xl font-bold text-cyan-400 mb-2 flex items-center">
                    <ArrowUpTrayIcon className="h-7 w-7 mr-3" />Import Question Bank
                </h2>
                <p className="text-gray-400 mb-4">Upload a JSON file to add questions in bulk. The importer will attempt to parse various formats.</p>
                <input type="file" ref={fileInputRef} onChange={handleFileImport} accept=".json" className="hidden" />
                <button onClick={() => fileInputRef.current?.click()} className="w-full bg-gray-600 text-white font-bold py-3 rounded-lg hover:bg-gray-700 transition-colors flex items-center justify-center text-lg">Select JSON File</button>
            </div>
            
            <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                <h2 className="text-3xl font-bold text-cyan-400 mb-2 flex items-center"><SparklesIcon className="h-8 w-8 mr-3 text-yellow-400" />AI Question Generator</h2>
                {/* AI Generator Form ... content unchanged */}
                <p className="text-gray-400 mb-6">Generate targeted questions based on official CMA exam sections and topics.</p>
                <form onSubmit={handleGenerate} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Part</label>
                            <select value={aiPart} onChange={e => setAiPart(e.target.value as 'Part 1' | 'Part 2')} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                                <option>Part 1</option><option>Part 2</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Section</label>
                            <select value={aiSection} onChange={e => setAiSection(e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" disabled={!curriculum}>
                                {!curriculum && <option>Loading sections...</option>}
                                {availableSections.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-sm font-medium text-gray-300 mb-1">Topic</label>
                            <select value={aiTopic} onChange={e => setAiTopic(e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" disabled={!curriculum}>
                                {availableTopics.map(t => <option key={t} value={t}>{t}</option>)}
                            </select>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Number of Questions</label>
                            <input type="number" min="1" max="10" value={aiCount} onChange={e => setAiCount(parseInt(e.target.value, 10))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Difficulty</label>
                                <select value={aiDifficulty} onChange={e => setAiDifficulty(e.target.value as any)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                                    <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
                                </select>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-300 mb-1">Type</label>
                                <select value={aiType} onChange={e => setAiType(e.target.value as any)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">
                                    <option value="theory">Theory</option><option value="problem">Problem</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" disabled={isGenerating || !curriculum} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center text-lg disabled:bg-gray-500">
                        {isGenerating ? <><Spinner /> <span className="ml-2">Generating...</span></> : 'Generate Questions'}
                    </button>
                    {aiError && <p className="text-red-400 text-sm mt-2 text-center">{aiError}</p>}
                </form>
            </div>
            
            {generatedQuestions.length > 0 && (
                <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-2xl font-bold text-cyan-400">Generated Questions</h3>
                        <button onClick={handleAddAllToBank} className="bg-green-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center">
                            <DocumentPlusIcon className="h-5 w-5 mr-2" /> Add All to Bank
                        </button>
                    </div>
                    <div className="space-y-4 max-h-[40rem] overflow-y-auto pr-2">
                         {generatedQuestions.map((q) => (
                            <div key={q.id} className="bg-gray-900/50 p-4 rounded-md">
                                <p className="font-semibold text-gray-300">{q.question}</p>
                                <p className="text-xs text-gray-500 mt-1">{q.part} | {q.section} | {q.topic} | {q.difficulty}</p>
                                <ul className="list-disc list-inside mt-2 space-y-1 text-sm text-gray-300">
                                    {q.choices.map((c, i) => <li key={i} className={i === q.answer.index ? 'text-green-400 font-bold' : ''}>{c}</li>)}
                                </ul>
                                <div className="flex justify-end mt-2">
                                    <button onClick={() => handleAddSingleToBank(q.id)} className="text-sm bg-green-700 hover:bg-green-600 text-white font-semibold py-1 px-3 rounded-md transition-colors">
                                        Add to Bank
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                <h2 className="text-3xl font-bold text-cyan-400 mb-2">{editingQuestion ? 'Edit Question' : 'Manual Question Builder'}</h2>
                <p className="text-gray-400 mb-6">{editingQuestion ? 'Update the details for your question below.' : 'Create your own practice questions to reinforce your learning.'}</p>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div><label className="block text-sm font-medium text-gray-300 mb-1">Part</label><select value={newQuestion.part} onChange={e => handleInputChange('part', e.target.value as 'Part 1' | 'Part 2')} className="w-full bg-gray-700 border-gray-600 rounded-md p-2"><option>Part 1</option><option>Part 2</option></select></div>
                        <div><label className="block text-sm font-medium text-gray-300 mb-1">Section</label><input type="text" value={newQuestion.section} onChange={e => handleInputChange('section', e.target.value)} placeholder="e.g., Cost Management" className="w-full bg-gray-700 border-gray-600 rounded-md p-2" required /></div>
                        <div><label className="block text-sm font-medium text-gray-300 mb-1">Topic</label><input type="text" value={newQuestion.topic} onChange={e => handleInputChange('topic', e.target.value)} placeholder="e.g., Activity-Based Costing" className="w-full bg-gray-700 border-gray-600 rounded-md p-2" required /></div>
                    </div>
                    <div><label className="block text-sm font-medium text-gray-300 mb-1">Question Text</label><textarea value={newQuestion.question} onChange={e => handleInputChange('question', e.target.value)} rows={4} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" required /></div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {newQuestion.choices.map((choice, index) => (<div key={index}><label className="block text-sm font-medium text-gray-300 mb-1">Choice {String.fromCharCode(65 + index)}</label><input type="text" value={choice} onChange={e => handleChoiceChange(index, e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" required /></div>))}
                    </div>
                    <div><label className="block text-sm font-medium text-gray-300 mb-1">Correct Answer</label><select value={newQuestion.answer.index} onChange={e => handleAnswerChange('index', parseInt(e.target.value, 10))} className="w-full bg-gray-700 border-gray-600 rounded-md p-2">{newQuestion.choices.map((_, index) => (<option key={index} value={index}>Choice {String.fromCharCode(65 + index)}</option>))}</select></div>
                    <div><label className="block text-sm font-medium text-gray-300 mb-1">Explanation</label><textarea value={newQuestion.answer.explanation} onChange={e => handleAnswerChange('explanation', e.target.value)} rows={3} className="w-full bg-gray-700 border-gray-600 rounded-md p-2" required /></div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label className="block text-sm font-medium text-gray-300 mb-1">Difficulty</label><select value={newQuestion.difficulty} onChange={e => handleInputChange('difficulty', e.target.value as 'easy' | 'medium' | 'hard')} className="w-full bg-gray-700 border-gray-600 rounded-md p-2"><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div>
                        <div><label className="block text-sm font-medium text-gray-300 mb-1">Type</label><select value={newQuestion.type} onChange={e => handleInputChange('type', e.target.value as 'theory' | 'problem')} className="w-full bg-gray-700 border-gray-600 rounded-md p-2"><option value="theory">Theory</option><option value="problem">Problem</option></select></div>
                    </div>
                    <div className="flex space-x-4">
                        <button type="submit" className="flex-grow bg-cyan-600 text-white font-bold py-3 rounded-lg hover:bg-cyan-700 transition-colors flex items-center justify-center text-lg"><PlusCircleIcon className="h-6 w-6 mr-2" /> {editingQuestion ? 'Update Question' : 'Add Question to Bank'}</button>
                        {editingQuestion && <button type="button" onClick={handleCancelEdit} className="flex-grow bg-gray-600 text-white font-bold py-3 rounded-lg hover:bg-gray-700">Cancel Edit</button>}
                    </div>
                </form>
            </div>
            
            {myQuestions.length > 0 && (
                 <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                    <h3 className="text-2xl font-bold text-cyan-400 mb-4">Manage Your Questions ({myQuestions.length})</h3>
                    <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                        {myQuestions.map((q) => (
                            <div key={q.id} className="bg-gray-900/50 p-4 rounded-md flex justify-between items-start">
                                <div>
                                    <p className="font-semibold text-gray-300">{q.question}</p>
                                    <p className="text-xs text-gray-500 mt-1">{q.part} | {q.section} | {q.topic}</p>
                                </div>
                                <div className="flex space-x-2 flex-shrink-0 ml-4">
                                    <button onClick={() => handleEditClick(q)} title="Edit Question" className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full"><PencilSquareIcon className="h-5 w-5"/></button>
                                    <button onClick={() => onDeleteQuestion(q.id)} title="Delete Question" className="p-2 text-red-400 hover:text-white hover:bg-red-600 rounded-full"><TrashIcon className="h-5 w-5"/></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};