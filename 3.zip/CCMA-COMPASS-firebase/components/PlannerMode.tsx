import React, { useState, useMemo, useEffect } from 'react';
import { generateStudyPlan } from '../services/geminiService';
import { loadAnalytics, calculatePerformanceMetrics } from '../services/analyticsService';
import { Spinner } from './Spinner';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export const PlannerMode: React.FC = () => {
    const [examDate, setExamDate] = useState('');
    const [weakAreas, setWeakAreas] = useState<string[]>([]);
    const [plan, setPlan] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [curriculum, setCurriculum] = useState<any>(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const curriculumRes = await fetch('/data/cma_curriculum.json');
                const curriculumData = await curriculumRes.json();
                setCurriculum(curriculumData);

                const analytics = await loadAnalytics();
                if (analytics.answerHistory.length > 10) {
                    const metrics = calculatePerformanceMetrics(analytics.answerHistory);
                    const suggestedWeakAreas = metrics.weakestTopics.map(t => t.section);
                    setWeakAreas(Array.from(new Set(suggestedWeakAreas)));
                }
            } catch (err) {
                 console.error("Failed to load initial data for Planner:", err);
                 setError("Could not load initial data. Planner may be unavailable.");
            }
        };
        fetchData();
    }, []);

    const allSections = useMemo(() => {
        if (!curriculum) return [];
        const sections = [
            ...curriculum["Part 1"].map((s: any) => s.name),
            ...curriculum["Part 2"].map((s: any) => s.name)
        ];
        return sections.sort();
    }, [curriculum]);

    const handleWeakAreaToggle = (section: string) => {
        setWeakAreas(prev => 
            prev.includes(section) ? prev.filter(t => t !== section) : [...prev, section]
        );
    };

    const handleGeneratePlan = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!examDate || weakAreas.length === 0) {
            setError("Please select your exam date and at least one weak area.");
            return;
        }
        
        setIsLoading(true);
        setError(null);
        setPlan('');

        try {
            const result = await generateStudyPlan(examDate, weakAreas);
            setPlan(result);
        } catch (err: any) {
            setError(err.message || "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in space-y-8">
            <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                <h2 className="text-3xl font-bold text-cyan-400 mb-2">AI Study Planner</h2>
                <p className="text-gray-400 mb-6">Get a personalized study plan. We've pre-selected some weak areas based on your analytics, but feel free to adjust them.</p>
                <form onSubmit={handleGeneratePlan} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Exam Date</label>
                        <input type="date" value={examDate} onChange={e => setExamDate(e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-md p-3" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">Select Your Weak Areas (Choose 2-4)</label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2 p-2 bg-gray-900/50 rounded-md">
                             {allSections.length === 0 && !error && (
                                 <p className="text-gray-400 col-span-full">Loading sections...</p>
                             )}
                             {allSections.map(section => (
                                <button type="button" key={section} onClick={() => handleWeakAreaToggle(section)} className={`p-2 text-sm rounded-md transition-colors text-left ${weakAreas.includes(section) ? 'bg-cyan-600 text-white font-semibold' : 'bg-gray-700 hover:bg-gray-600'}`}>
                                    {section}
                                </button>
                            ))}
                        </div>
                    </div>
                    <button type="submit" disabled={isLoading || !curriculum} className="w-full bg-cyan-600 text-white font-bold py-3 rounded-lg hover:bg-cyan-700 transition-colors disabled:bg-gray-500 flex items-center justify-center text-lg">
                        {isLoading ? <Spinner /> : 'Generate My Plan'}
                    </button>
                    {error && <p className="text-red-400 text-sm mt-4 text-center">{error}</p>}
                </form>
            </div>
            
            {plan && (
                 <div className="bg-gray-800 p-8 rounded-xl shadow-2xl">
                    <h3 className="text-2xl font-bold text-cyan-400 mb-4">Your Personalized Plan</h3>
                     <div className="prose prose-invert max-w-none text-gray-300">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>{plan}</ReactMarkdown>
                    </div>
                </div>
            )}
        </div>
    );
};
