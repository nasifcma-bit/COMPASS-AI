import React, { useMemo, useState, useEffect } from 'react';
import { loadAnalytics, calculatePerformanceMetrics } from '../services/analyticsService';
import { AnalyticsData, Question, AppMode, PracticeFilters } from '../types';
import { SectionBarChart, HistoryLineChart } from './AnalyticsCharts';
import { LightBulbIcon, ShieldExclamationIcon, QuestionMarkCircleIcon, CheckCircleIcon, XCircleIcon, FlagIcon, FireIcon, AcademicCapIcon, BeakerIcon } from '@heroicons/react/24/outline';
import { Spinner } from './Spinner';


const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 80) return 'text-green-400';
    if (accuracy >= 60) return 'text-yellow-400';
    return 'text-red-400';
};

const StatCard: React.FC<{ title: string; value: string; colorClass?: string }> = ({ title, value, colorClass = 'text-cyan-400' }) => (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
        <h3 className="text-md font-medium text-gray-400">{title}</h3>
        <p className={`text-3xl font-bold mt-2 ${colorClass}`}>{value}</p>
    </div>
);

const FilterButton: React.FC<{ label: string; value: any; activeValue: any; onClick: (value: any) => void; }> = ({ label, value, activeValue, onClick }) => (
    <button onClick={() => onClick(value)} className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${activeValue === value ? 'bg-cyan-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>
        {label}
    </button>
);

const QuestionReviewList: React.FC<{ title: string; questionIds: string[]; allQuestions: Question[]; }> = ({ title, questionIds, allQuestions }) => {
    const [expandedId, setExpandedId] = useState<string | null>(null);

    const questions = useMemo(() => {
        const questionMap = new Map(allQuestions.map(q => [q.id, q]));
        return Array.from(new Set(questionIds)).map(id => questionMap.get(id)).filter(Boolean) as Question[];
    }, [questionIds, allQuestions]);
    
    if (questions.length === 0) {
        return <p className="text-gray-500 text-center py-4">No questions to show in this category.</p>;
    }

    return (
        <div>
            <h4 className="text-lg font-semibold text-cyan-400 mb-3">{title} ({questions.length})</h4>
            <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                {questions.map(q => (
                    <div key={q.id} className="bg-gray-900/50 p-3 rounded-md">
                        <p onClick={() => setExpandedId(expandedId === q.id ? null : q.id)} className="cursor-pointer font-medium text-gray-300 hover:text-white">
                            {q.question}
                        </p>
                        {expandedId === q.id && (
                             <div className="mt-3 pt-3 border-t border-gray-700 animate-fade-in">
                                 <p className="text-xs text-gray-500">{q.part} | {q.section} | {q.topic}</p>
                                 <ul className="list-disc list-inside mt-2 space-y-1 text-sm text-gray-400">
                                     {q.choices.map((c, i) => <li key={i} className={i === q.answer.index ? 'text-green-400 font-bold' : ''}>{c}</li>)}
                                 </ul>
                                 <div className="mt-2 p-2 bg-gray-800 rounded">
                                     <p className="text-sm font-semibold text-yellow-300">Explanation:</p>
                                     <p className="text-sm text-gray-300">{q.answer.explanation}</p>
                                 </div>
                             </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};


interface AnalyticsViewProps {
    questionBank: Question[];
    onNavigate: (mode: AppMode, prefill?: Partial<PracticeFilters>) => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ questionBank, onNavigate }) => {
    const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
    const [filterPart, setFilterPart] = useState<'Part 1' | 'Part 2' | 'All'>('All');
    const [filterDate, setFilterDate] = useState<'7d' | '30d' | 'all'>('all');
    const [partSections, setPartSections] = useState<{ [key: string]: string[] }>({});
    const [reviewTab, setReviewTab] = useState<'incorrect' | 'flagged' | 'danger'>('incorrect');

    useEffect(() => {
        const fetchData = async () => {
            setAnalytics(await loadAnalytics());
        };
        fetchData();

        fetch('/data/cma_curriculum.json')
            .then(res => res.json())
            .then(data => {
                setPartSections({
                    'Part 1': data['Part 1'].map((s: any) => s.name),
                    'Part 2': data['Part 2'].map((s: any) => s.name),
                });
            });
    }, []);
    
    const filteredAnswerHistory = useMemo(() => {
        if (!analytics) return [];
        let history = analytics.answerHistory;
        if (filterPart !== 'All') {
            history = history.filter(a => a.part === filterPart);
        }
        if (filterDate !== 'all') {
            const days = filterDate === '7d' ? 7 : 30;
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - days);
            history = history.filter(a => new Date(a.date) >= cutoff);
        }
        return history;
    }, [analytics, filterPart, filterDate]);

    const performanceMetrics = useMemo(() => calculatePerformanceMetrics(filteredAnswerHistory), [filteredAnswerHistory]);
    
    const filteredBySection = useMemo(() => {
        if (!analytics) return {};
        const sectionsToShow = filterPart === 'All' 
            ? [...(partSections['Part 1'] || []), ...(partSections['Part 2'] || [])] 
            : partSections[filterPart] || [];
        const result: AnalyticsData['bySection'] = {};
        for(const section in analytics.bySection) {
            if(sectionsToShow.includes(section)) {
                result[section] = analytics.bySection[section];
            }
        }
        return result;
    }, [analytics, filterPart, partSections]);
    
    if (!analytics) {
        return <div className="flex justify-center items-center h-64"><Spinner/></div>;
    }
    
    const hasEnoughDataForCharts = filteredAnswerHistory.length > 0;

    return (
        <div className="animate-fade-in space-y-8">
            <div className="flex flex-wrap justify-between items-center gap-4">
                <h2 className="text-3xl font-bold text-cyan-400">Performance Center</h2>
                <div className="flex flex-wrap gap-x-4 gap-y-2">
                    <div className="flex items-center space-x-2">
                        <FilterButton label="All Parts" value="All" activeValue={filterPart} onClick={setFilterPart} />
                        <FilterButton label="Part 1" value="Part 1" activeValue={filterPart} onClick={setFilterPart} />
                        <FilterButton label="Part 2" value="Part 2" activeValue={filterPart} onClick={setFilterPart} />
                    </div>
                     <div className="flex items-center space-x-2">
                        <FilterButton label="Last 7 Days" value="7d" activeValue={filterDate} onClick={setFilterDate} />
                        <FilterButton label="Last 30 Days" value="30d" activeValue={filterDate} onClick={setFilterDate} />
                        <FilterButton label="All Time" value="all" activeValue={filterDate} onClick={setFilterDate} />
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <StatCard title="Overall Accuracy" value={`${performanceMetrics.overallAccuracy}%`} colorClass={getAccuracyColor(performanceMetrics.overallAccuracy)} />
                <StatCard title="Questions Answered" value={performanceMetrics.totalQuestions.toString()} />
                <StatCard title="Mastery Zone" value={performanceMetrics.confidenceMatrix.mastery.count.toString()} colorClass="text-green-400" />
                <StatCard title="Danger Zone" value={performanceMetrics.confidenceMatrix.danger.count.toString()} colorClass="text-red-400" />
            </div>
            
            {!hasEnoughDataForCharts ? (
                 <div className="text-center bg-gray-800 p-12 rounded-lg">
                    <h3 className="text-xl text-gray-400">No analytics data for this period.</h3>
                    <p className="text-gray-500 mt-2">Complete a practice session or broaden your filters!</p>
                </div>
            ) : (
                <>
                    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                        {/* Left side: Weakest Topics & Confidence Matrix */}
                        <div className="lg:col-span-2 space-y-8">
                            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                                <h3 className="text-xl font-semibold mb-4 text-cyan-400 flex items-center"><LightBulbIcon className="h-6 w-6 mr-2 text-yellow-300"/> Actionable Insights</h3>
                                <div className="space-y-3">
                                    {performanceMetrics.weakestTopics.length > 0 ? performanceMetrics.weakestTopics.map(topic => (
                                        <div key={topic.topic} className="bg-gray-900/50 p-3 rounded-md">
                                            <div className="flex justify-between items-center">
                                                <div>
                                                    <p className="font-semibold text-gray-200">{topic.topic}</p>
                                                    <p className={`text-sm font-bold ${getAccuracyColor(topic.accuracy * 100)}`}>{Math.round(topic.accuracy * 100)}% <span className="text-xs text-gray-400 font-normal">({topic.total} Qs)</span></p>
                                                </div>
                                                <button onClick={() => onNavigate('Practice', { part: topic.part, section: topic.section, topic: topic.topic, count: 10 })} className="text-xs bg-cyan-700 hover:bg-cyan-600 text-white font-semibold py-1 px-2 rounded-md">Practice</button>
                                            </div>
                                        </div>
                                    )) : <p className="text-gray-500 text-sm">Not enough data to identify weak topics. Keep practicing!</p>}
                                </div>
                            </div>
                            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                                <h3 className="text-xl font-semibold mb-4 text-cyan-400">Confidence Matrix</h3>
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="bg-green-900/50 p-3 rounded text-center"><p className="font-bold text-2xl text-green-300">{performanceMetrics.confidenceMatrix.mastery.count}</p><p className="text-xs text-green-400">Mastery</p></div>
                                    <div className="bg-yellow-900/50 p-3 rounded text-center"><p className="font-bold text-2xl text-yellow-300">{performanceMetrics.confidenceMatrix.uncertain.count}</p><p className="text-xs text-yellow-400">Uncertain</p></div>
                                    <div className="bg-orange-900/50 p-3 rounded text-center"><p className="font-bold text-2xl text-orange-300">{performanceMetrics.confidenceMatrix.learning.count}</p><p className="text-xs text-orange-400">Learning</p></div>
                                    <div className="bg-red-900/50 p-3 rounded text-center"><p className="font-bold text-2xl text-red-300">{performanceMetrics.confidenceMatrix.danger.count}</p><p className="text-xs text-red-400">Danger Zone</p></div>
                                </div>
                            </div>
                        </div>
                        {/* Right Side: Charts */}
                        <div className="lg:col-span-3 bg-gray-800 p-6 rounded-lg shadow-lg">
                            <h3 className="text-xl font-semibold mb-4 text-cyan-400">Accuracy by Section</h3>
                            <div className="h-80">
                                <SectionBarChart analytics={{...analytics, bySection: filteredBySection}} />
                            </div>
                        </div>
                    </div>
                    
                    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                        <h3 className="text-xl font-semibold mb-4 text-cyan-400">Performance Over Time</h3>
                         <div className="h-80">
                             {analytics.sessionHistory.length < 2 ? 
                                <p className="text-center text-gray-500 pt-12">Complete at least two sessions to see your progress trend.</p> :
                                <HistoryLineChart analytics={analytics} />
                             }
                        </div>
                    </div>
                    
                    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                        <h3 className="text-2xl font-bold text-cyan-400 mb-4">Review Center</h3>
                        <div className="flex border-b border-gray-700 mb-4">
                            <button onClick={() => setReviewTab('incorrect')} className={`px-4 py-2 text-sm font-semibold flex items-center ${reviewTab === 'incorrect' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400'}`}><XCircleIcon className="h-5 w-5 mr-2" /> Incorrect Answers</button>
                            <button onClick={() => setReviewTab('danger')} className={`px-4 py-2 text-sm font-semibold flex items-center ${reviewTab === 'danger' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400'}`}><FireIcon className="h-5 w-5 mr-2" /> Danger Zone</button>
                            <button onClick={() => setReviewTab('flagged')} className={`px-4 py-2 text-sm font-semibold flex items-center ${reviewTab === 'flagged' ? 'text-white border-b-2 border-cyan-400' : 'text-gray-400'}`}><FlagIcon className="h-5 w-5 mr-2" /> Flagged Questions</button>
                        </div>
                        {reviewTab === 'incorrect' && <QuestionReviewList title="Incorrectly Answered" questionIds={performanceMetrics.incorrectQuestions} allQuestions={questionBank} />}
                        {reviewTab === 'danger' && <QuestionReviewList title="Danger Zone (High Confidence, Incorrect)" questionIds={performanceMetrics.confidenceMatrix.danger.questions} allQuestions={questionBank} />}
                        {reviewTab === 'flagged' && <QuestionReviewList title="Flagged for Review" questionIds={analytics.flaggedQuestions} allQuestions={questionBank} />}
                    </div>
                </>
            )}
        </div>
    );
};
