import React, { useMemo, useState, useEffect } from 'react';
import { loadAnalytics } from '../services/analyticsService';
import { useAuth } from '../App';
import { Badge, GamificationData, AnalyticsData } from '../types';
import { ArrowRightOnRectangleIcon } from '@heroicons/react/24/outline';
import { Spinner } from './Spinner';


interface ProfileViewProps {
    onLogout: () => void;
}

const StatCard: React.FC<{ title: string; value: string; icon: string; }> = ({ title, value, icon }) => (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg flex items-center space-x-4">
        <div className="text-4xl">{icon}</div>
        <div>
            <h3 className="text-md font-medium text-gray-400">{title}</h3>
            <p className="text-3xl font-bold mt-1 text-cyan-400">{value}</p>
        </div>
    </div>
);

const BadgeCard: React.FC<{ badge: Badge }> = ({ badge }) => (
    <div className={`bg-gray-800 p-4 rounded-lg shadow-lg text-center transition-opacity ${badge.unlocked ? 'opacity-100' : 'opacity-40'}`}>
        <div className="text-5xl mb-3">{badge.icon}</div>
        <h4 className={`font-bold ${badge.unlocked ? 'text-yellow-300' : 'text-gray-400'}`}>{badge.name}</h4>
        <p className="text-xs text-gray-500 mt-1">{badge.description}</p>
    </div>
);

export const ProfileView: React.FC<ProfileViewProps> = ({ onLogout }) => {
    const { user } = useAuth();
    const [gamificationData, setGamificationData] = useState<GamificationData | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            const analytics = await loadAnalytics();
            setGamificationData(analytics.gamification);
        };
        fetchData();
    }, []);

    if (!gamificationData) {
        return <div className="flex justify-center items-center h-64"><Spinner/></div>;
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in space-y-8">
             <div className="flex justify-between items-start">
                <div>
                    <h2 className="text-3xl font-bold text-cyan-400">Welcome!</h2>
                    <p className="text-gray-400 mt-1">{user?.email}</p>
                </div>
                 <button 
                    onClick={onLogout}
                    className="flex items-center px-4 py-2 bg-gray-700 text-white rounded-md hover:bg-red-700 transition-colors"
                 >
                    <ArrowRightOnRectangleIcon className="h-5 w-5 mr-2"/>
                    Logout
                 </button>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <StatCard title="Daily Streak" value={`${gamificationData.dailyStreak} Days`} icon="🔥" />
                <StatCard title="Badges Unlocked" value={`${gamificationData.badges.filter(b => b.unlocked).length} / ${gamificationData.badges.length}`} icon="🏆" />
             </div>

             <div className="bg-gray-900/50 p-6 rounded-xl">
                 <h3 className="text-2xl font-bold text-cyan-400 mb-4">Achievements</h3>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                     {gamificationData.badges.map(badge => (
                        <BadgeCard key={badge.id} badge={badge} />
                     ))}
                 </div>
             </div>
        </div>
    );
};
