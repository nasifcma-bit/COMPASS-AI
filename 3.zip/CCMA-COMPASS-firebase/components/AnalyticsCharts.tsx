import React, { useEffect, useRef, useState } from 'react';
import {
    Chart,
    BarController,
    BarElement,
    CategoryScale,
    LinearScale,
    Title,
    Tooltip,
    Legend,
    LineController,
    LineElement,
    PointElement,
    TimeScale,
    TimeSeriesScale,
    RadarController,
    RadialLinearScale,
    Filler,
    ChartOptions,
} from 'chart.js';
import 'chartjs-adapter-date-fns';
// FIX: Corrected relative import paths. The original error was due to the imported modules not being defined.
import { AnalyticsData } from '../types';

Chart.register(
    BarController,
    BarElement,
    CategoryScale,
    LinearScale,
    Title,
    Tooltip,
    Legend,
    LineController,
    LineElement,
    PointElement,
    TimeScale,
    TimeSeriesScale,
    RadarController,
    RadialLinearScale,
    Filler
);

// Helper to calculate accuracy from stats
const calculateAccuracy = (stats: { correct: number; total: number }) => (stats.total > 0 ? (stats.correct / stats.total) * 100 : 0);

const getBaseChartOptions = (): ChartOptions => ({
    maintainAspectRatio: false,
    plugins: {
        legend: { labels: { color: '#d1d5db', font: { size: 14 }}},
        tooltip: {
            backgroundColor: 'rgba(31, 41, 55, 0.9)',
            titleColor: '#e5e7eb',
            bodyColor: '#d1d5db',
            borderColor: '#4b5563',
            borderWidth: 1,
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#d1d5db', font: { size: 12 }}
        },
        x: {
            grid: { color: 'rgba(255, 255, 255, 0.1)' },
            ticks: { color: '#d1d5db', font: { size: 12 }}
        }
    }
});


// --- Section Performance Bar Chart ---
interface SectionBarChartProps { analytics: AnalyticsData; }
export const SectionBarChart: React.FC<SectionBarChartProps> = ({ analytics }) => {
    const chartRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        if (!chartRef.current) return;
        const sectionData = Object.entries(analytics.bySection).map(([sectionName, sectionStats]) => {
            const allTopics = Object.values(sectionStats);
            const totalCorrect = allTopics.reduce((sum, topic) => sum + topic.correct, 0);
            const totalQuestions = allTopics.reduce((sum, topic) => sum + topic.total, 0);
            return { section: sectionName, accuracy: totalQuestions > 0 ? (totalCorrect / totalQuestions) * 100 : 0 };
        });

        const chart = new Chart(chartRef.current, {
            type: 'bar',
            data: {
                labels: sectionData.map(d => d.section),
                datasets: [{
                    label: 'Accuracy %',
                    data: sectionData.map(d => d.accuracy),
                    backgroundColor: 'rgba(34, 211, 238, 0.6)',
                    borderColor: 'rgba(34, 211, 238, 1)',
                    borderWidth: 1
                }]
            },
            options: { ...getBaseChartOptions(), scales: { ...getBaseChartOptions().scales, y: { ...getBaseChartOptions().scales?.y, max: 100 }}} as ChartOptions<'bar'>,
        });
        return () => chart.destroy();
    }, [analytics]);

    return <canvas ref={chartRef}></canvas>;
};


// --- History Line Chart ---
interface HistoryLineChartProps { analytics: AnalyticsData; }
export const HistoryLineChart: React.FC<HistoryLineChartProps> = ({ analytics }) => {
    const chartRef = useRef<HTMLCanvasElement>(null);
    const [dataType, setDataType] = useState<'accuracy' | 'time'>('accuracy');

    useEffect(() => {
        if (!chartRef.current || !analytics.sessionHistory) return;
        
        const history = analytics.sessionHistory;
        const isTimeView = dataType === 'time';

        const chartOptions = {
            ...getBaseChartOptions(),
            scales: {
                x: {
                    ...getBaseChartOptions().scales?.x,
                    type: 'time',
                    time: { unit: 'day', tooltipFormat: 'MMM d, yyyy' },
                    title: { display: true, text: 'Date', color: '#9ca3af' }
                },
                y: {
                     ...getBaseChartOptions().scales?.y,
                     max: isTimeView ? undefined : 100, // No max for time
                     title: { display: true, text: isTimeView ? 'Avg. Time (s)' : 'Accuracy %', color: '#9ca3af' }
                }
            }
        } as ChartOptions<'line'>;
        
        const chart = new Chart(chartRef.current, {
            type: 'line',
            data: {
                labels: history.map(s => new Date(s.date)),
                datasets: [{
                    label: isTimeView ? 'Avg. Time (s)' : 'Session Accuracy %',
                    data: history.map(s => isTimeView ? s.avgTimePerQuestion : s.accuracy),
                    borderColor: isTimeView ? 'rgba(139, 92, 246, 1)' : 'rgba(75, 192, 192, 1)',
                    backgroundColor: isTimeView ? 'rgba(139, 92, 246, 0.2)' : 'rgba(75, 192, 192, 0.2)',
                    tension: 0.1,
                    fill: true
                }]
            },
            options: chartOptions,
        });
        
        return () => chart.destroy();
    }, [analytics, dataType]);
    
    const ToggleButton: React.FC<{ type: 'accuracy' | 'time'; label: string }> = ({ type, label }) => (
         <button onClick={() => setDataType(type)} className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${dataType === type ? 'bg-cyan-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>
            {label}
        </button>
    );

    return (
        <div>
            <div className="flex justify-end space-x-2 mb-4">
                <ToggleButton type="accuracy" label="Accuracy"/>
                <ToggleButton type="time" label="Avg. Time"/>
            </div>
            <div className="h-72">
                 <canvas ref={chartRef}></canvas>
            </div>
        </div>
    );
};
