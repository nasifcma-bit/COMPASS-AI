import React from 'react';
import { BookOpenIcon, BeakerIcon, WrenchScrewdriverIcon, ChartBarIcon, CalendarIcon, UserCircleIcon, AcademicCapIcon } from '@heroicons/react/24/outline';

interface HeaderProps {
    currentMode: string;
    onModeChange: (mode: string) => void;
}

const navItems = [
    { name: 'Practice', icon: BookOpenIcon },
    { name: 'Curriculum', icon: AcademicCapIcon },
    { name: 'Explain', icon: BeakerIcon },
    { name: 'Builder', icon: WrenchScrewdriverIcon },
    { name: 'Analytics', icon: ChartBarIcon },
    { name: 'Planner', icon: CalendarIcon },
    { name: 'Profile', icon: UserCircleIcon },
];

export const Header: React.FC<HeaderProps> = ({ currentMode, onModeChange }) => {
    return (
        <header className="bg-gray-900 text-white shadow-md">
            <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
                <div className="flex items-center">
                    <h1 className="text-xl font-bold text-cyan-400">CMA Compass</h1>
                </div>
                <div className="hidden md:flex items-center space-x-2">
                    {navItems.map(item => (
                        <button
                            key={item.name}
                            onClick={() => onModeChange(item.name)}
                            className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                                currentMode === item.name
                                ? 'bg-cyan-600 text-white'
                                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                            }`}
                        >
                            <item.icon className="h-5 w-5 mr-2" />
                            {item.name}
                        </button>
                    ))}
                </div>
                {/* Mobile menu could be added here */}
            </nav>
        </header>
    );
};