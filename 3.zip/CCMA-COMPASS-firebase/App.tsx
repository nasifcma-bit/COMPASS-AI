import React, { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { User, onAuthStateChanged, signOut } from 'firebase/auth';
import { auth } from './services/firebase';
import { Header } from './components/Header';
import { PracticeMode } from './components/PracticeMode';
import { ExplainMode } from './components/ExplainMode';
import { BuilderMode } from './components/BuilderMode';
import { AnalyticsView } from './components/AnalyticsView';
import { PlannerMode } from './components/PlannerMode';
import { ProfileView } from './components/ProfileView';
import { LoginPage } from './components/LoginPage';
import { CurriculumMode } from './components/CurriculumMode';
import { AppMode, Question, PracticeFilters } from './types';
import { loadUserQuestionBank, saveUserQuestionBank } from './services/analyticsService';
import { loadAndTransformUserQuestions } from './services/questionService';
import { Toast } from './components/Toast';
import { Spinner } from './components/Spinner';

// A small, static question bank to get users started.
const INITIAL_QUESTION_BANK: Omit<Question, 'source'>[] = [
    // ... (content unchanged)
];

// Context for providing user state
export const AuthContext = createContext<{ user: User | null }>({ user: null });
export const useAuth = () => useContext(AuthContext);

// Context for showing toast notifications
const ToastContext = createContext((message: string, type: 'success' | 'error') => {});
export const useToast = () => useContext(ToastContext);

const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [isLoadingAuth, setIsLoadingAuth] = useState(true);
    const [currentMode, setCurrentMode] = useState<AppMode>('Practice');
    const [questionBank, setQuestionBank] = useState<Question[]>([]);
    const [userQuestions, setUserQuestions] = useState<Question[]>([]);
    const [prefilledConcept, setPrefilledConcept] = useState<{ concept: string; context: string } | null>(null);
    const [prefilledPracticeFilters, setPrefilledPracticeFilters] = useState<Partial<PracticeFilters> | null>(null);
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

    useEffect(() => {
        // Listen for authentication state changes
        const unsubscribe = onAuthStateChanged(auth, user => {
            setCurrentUser(user);
            setIsLoadingAuth(false);
        });
        return () => unsubscribe(); // Cleanup subscription on unmount
    }, []);

    useEffect(() => {
        if (!currentUser) return;

        const fetchAllQuestions = async () => {
            const existingUserBank = await loadUserQuestionBank();
            const existingIds = new Set(existingUserBank.map(q => q.id));

            const initialWithSource = INITIAL_QUESTION_BANK.map(q => ({ ...q, source: 'system' as const }));
            const fetchedQuestions = await loadAndTransformUserQuestions();
            
            const allDefaultQuestions = [...initialWithSource, ...fetchedQuestions];
            const newDefaultQuestions = allDefaultQuestions.filter(q => !existingIds.has(q.id));
            
            let finalBank = [...existingUserBank];

            if (newDefaultQuestions.length > 0) {
                finalBank = [...existingUserBank, ...newDefaultQuestions];
                await saveUserQuestionBank(finalBank);
            }
            
            setQuestionBank(finalBank);
            setUserQuestions(finalBank.filter(q => q.source === 'user' || q.source === 'import'));
        };

        fetchAllQuestions();
    }, [currentUser]);

    const handleLogout = async () => {
        try {
            await signOut(auth);
            // State will be cleared automatically by the onAuthStateChanged listener
            setQuestionBank([]);
            setUserQuestions([]);
            setCurrentMode('Practice');
        } catch (error) {
            console.error("Error signing out: ", error);
            showToast("Failed to logout. Please try again.", 'error');
        }
    };

    const handleNavigate = (mode: AppMode, prefill?: any) => {
        setPrefilledConcept(null);
        setPrefilledPracticeFilters(null);

        if (prefill) {
            if (mode === 'Explain') {
                setPrefilledConcept(prefill);
            } else if (mode === 'Practice') {
                setPrefilledPracticeFilters(prefill);
            }
        }
        setCurrentMode(mode);
    };
    
    const showToast = (message: string, type: 'success' | 'error') => {
        setToast({ message, type });
        setTimeout(() => setToast(null), 3000);
    };

    const handleAddToBank = useCallback(async (newQuestions: Question[]): Promise<{ added: number, duplicates: number }> => {
        const currentBank = await loadUserQuestionBank();
        const existingIds = new Set(currentBank.map(q => q.id));
        const uniqueNewQuestions = newQuestions.filter(q => !existingIds.has(q.id));
        
        if (uniqueNewQuestions.length > 0) {
            const updatedBank = [...currentBank, ...uniqueNewQuestions];
            await saveUserQuestionBank(updatedBank);
            
            setQuestionBank(updatedBank);
            setUserQuestions(updatedBank.filter(q => q.source === 'user' || q.source === 'import'));
        }
        
        return { added: uniqueNewQuestions.length, duplicates: newQuestions.length - uniqueNewQuestions.length };
    }, []);

    const handleDeleteQuestion = useCallback(async (questionId: string) => {
        const currentBank = await loadUserQuestionBank();
        const updatedBank = currentBank.filter(q => q.id !== questionId);
        await saveUserQuestionBank(updatedBank);

        setQuestionBank(updatedBank);
        setUserQuestions(updatedBank.filter(q => q.source === 'user' || q.source === 'import'));
        showToast('Question deleted successfully.', 'success');
    }, []);

    const handleUpdateQuestion = useCallback(async (updatedQuestion: Question) => {
        const currentBank = await loadUserQuestionBank();
        const updatedBank = currentBank.map(q => q.id === updatedQuestion.id ? updatedQuestion : q);
        await saveUserQuestionBank(updatedBank);

        setQuestionBank(updatedBank);
        setUserQuestions(updatedBank.filter(q => q.source === 'user' || q.source === 'import'));
        showToast('Question updated successfully.', 'success');
    }, []);
    
    const renderCurrentMode = () => {
        switch (currentMode) {
            case 'Practice':
                return <PracticeMode questionBank={questionBank} onNavigate={handleNavigate} prefilledFilters={prefilledPracticeFilters} />;
            case 'Curriculum':
                return <CurriculumMode onNavigate={handleNavigate} />;
            case 'Explain':
                return <ExplainMode onAddToBank={handleAddToBank} prefill={prefilledConcept} />;
            case 'Builder':
                return <BuilderMode userQuestions={userQuestions} onAddToBank={handleAddToBank} onDeleteQuestion={handleDeleteQuestion} onUpdateQuestion={handleUpdateQuestion} />;
            case 'Analytics':
                return <AnalyticsView questionBank={questionBank} onNavigate={handleNavigate} />;
            case 'Planner':
                return <PlannerMode />;
            case 'Profile':
                return <ProfileView onLogout={handleLogout} />;
            default:
                return <PracticeMode questionBank={questionBank} onNavigate={handleNavigate} prefilledFilters={prefilledPracticeFilters} />;
        }
    };
    
    if (isLoadingAuth) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-gray-900">
                <Spinner />
            </div>
        );
    }

    if (!currentUser) {
        return <LoginPage />;
    }

    return (
        <AuthContext.Provider value={{ user: currentUser }}>
            <ToastContext.Provider value={showToast}>
                <div className="bg-gray-900 text-white min-h-screen font-sans">
                    {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
                    <Header currentMode={currentMode} onModeChange={handleNavigate} />
                    <main className="container mx-auto p-4 md:p-8">
                        {renderCurrentMode()}
                    </main>
                </div>
            </ToastContext.Provider>
        </AuthContext.Provider>
    );
};

export default App;