// FIX: Removed self-import of AppMode which caused a conflict.
export type AppMode = 'Practice' | 'Curriculum' | 'Explain' | 'Builder' | 'Analytics' | 'Planner' | 'Profile';

export interface Question {
  id: string;
  part: 'Part 1' | 'Part 2';
  section: string;
  topic: string;
  question: string;
  choices: string[];
  answer: {
    index: number;
    explanation: string;
  };
  difficulty: 'easy' | 'medium' | 'hard';
  type: 'theory' | 'problem';
  source?: 'system' | 'user' | 'import';
}

export interface ExplainedConcept {
  id: string;
  concept: string;
  context: string;
  explanation: string; // The rich markdown explanation
  timestamp: string; // ISO string
  bookmarked: boolean;
}

export interface PracticeFilters {
  part: 'Part 1' | 'Part 2' | 'All';
  section: string;
  count: number;
  type: 'mixed' | 'theory' | 'problem';
  difficulty: 'mixed' | 'easy' | 'medium' | 'hard';
  topic?: string;
}

export interface TopicStats {
  correct: number;
  total: number;
  totalTime: number; // in seconds
}

export interface SectionStats {
  [topic: string]: TopicStats;
}

export interface SessionSummary {
  accuracy: number; // percentage
  questionsAnswered: number;
  avgTimePerQuestion: number; // seconds
  date: string; // ISO string
}

export interface Badge {
    id: string;
    name: string;
    description: string;
    icon: string;
    unlocked: boolean;
}

export interface GamificationData {
    dailyStreak: number;
    lastPracticeDate: string | null; // ISO string
    badges: Badge[];
}

export interface AnswerRecord {
    questionId: string;
    isCorrect: boolean;
    confidence?: 'low' | 'medium' | 'high';
    part: 'Part 1' | 'Part 2';
    section: string;
    topic: string;
    date: string; // ISO string
}

export interface AnalyticsData {
  bySection: {
    [section: string]: SectionStats;
  };
  sessionHistory: SessionSummary[];
  flaggedQuestions: string[];
  gamification: GamificationData;
  answerHistory: AnswerRecord[];
}

export interface LOS {
    id: string;
    part: 'Part 1' | 'Part 2';
    section: string;
    text: string;
}